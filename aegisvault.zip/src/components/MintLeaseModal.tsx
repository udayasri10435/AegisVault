import React, { useState } from 'react';
import { useVault } from '../context/VaultContext';
import { DynamicEngineType } from '../types/vault';
import { Zap, X, Database, Cloud, Server, Github, Clock, ShieldCheck } from 'lucide-react';

interface MintLeaseModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const MintLeaseModal: React.FC<MintLeaseModalProps> = ({ isOpen, onClose }) => {
  const { dynamicEngines, issueDynamicCredential, setCurrentTab } = useVault();

  const [selectedEngineId, setSelectedEngineId] = useState<DynamicEngineType>('postgresql');
  const [selectedRole, setSelectedRole] = useState('read_only_analyst');
  const [ttlMinutes, setTtlMinutes] = useState(60);

  if (!isOpen) return null;

  const currentEngine = dynamicEngines.find(e => e.id === selectedEngineId) || dynamicEngines[0];

  const handleSelectEngine = (engineId: DynamicEngineType) => {
    setSelectedEngineId(engineId);
    const eng = dynamicEngines.find(e => e.id === engineId);
    if (eng && eng.roleTemplates[0]) {
      setSelectedRole(eng.roleTemplates[0]);
    }
  };

  const handleMint = (e: React.FormEvent) => {
    e.preventDefault();
    issueDynamicCredential(selectedEngineId, selectedRole, ttlMinutes * 60);
    onClose();
    setCurrentTab('dynamic');
  };

  const getEngineIcon = (id: DynamicEngineType) => {
    switch (id) {
      case 'postgresql': return Database;
      case 'aws-sts': return Cloud;
      case 'redis': return Server;
      case 'github': return Github;
      default: return Zap;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4">
      <div className="w-full max-w-xl rounded-xl border border-slate-800 bg-[#0F172A] p-6 shadow-2xl space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <Zap className="h-4 w-4 text-amber-400" />
            <h3 className="text-sm font-bold text-white">
              Mint Ephemeral Dynamic Credentials
            </h3>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded cursor-pointer"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <form onSubmit={handleMint} className="space-y-4 text-xs">
          {/* Engine Selector */}
          <div>
            <label className="block text-slate-400 mb-1.5 font-medium">Select Dynamic Backend</label>
            <div className="grid grid-cols-2 gap-2">
              {dynamicEngines.map(eng => {
                const Icon = getEngineIcon(eng.id);
                const isSelected = selectedEngineId === eng.id;

                return (
                  <div
                    key={eng.id}
                    onClick={() => handleSelectEngine(eng.id)}
                    className={`p-3 rounded-lg border cursor-pointer transition-all flex items-start gap-2.5 ${
                      isSelected
                        ? 'border-amber-500/60 bg-amber-950/20 text-white'
                        : 'border-slate-800 bg-slate-900/40 text-slate-300 hover:border-slate-700'
                    }`}
                  >
                    <Icon className={`h-4 w-4 shrink-0 mt-0.5 ${isSelected ? 'text-amber-400' : 'text-slate-500'}`} />
                    <div>
                      <div className="font-semibold text-xs">{eng.name}</div>
                      <div className="text-[10px] text-slate-400 mt-0.5 line-clamp-1">{eng.targetEndpoint}</div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Privilege Role Template */}
          <div>
            <label className="block text-slate-400 mb-1 font-medium">Privilege Role Template</label>
            <div className="grid grid-cols-3 gap-2">
              {currentEngine.roleTemplates.map(role => (
                <button
                  key={role}
                  type="button"
                  onClick={() => setSelectedRole(role)}
                  className={`py-2 px-2.5 rounded-lg border font-mono text-xs transition-all ${
                    selectedRole === role
                      ? 'border-amber-500 bg-amber-500/10 text-amber-300 font-semibold'
                      : 'border-slate-800 bg-slate-900 text-slate-400 hover:text-white'
                  }`}
                >
                  {role}
                </button>
              ))}
            </div>
          </div>

          {/* Lease TTL Duration */}
          <div>
            <label className="block text-slate-400 mb-1 font-medium">Lease Time-To-Live (Auto-Revoke)</label>
            <div className="grid grid-cols-4 gap-2">
              {[
                { label: '15 min', minutes: 15 },
                { label: '1 hour', minutes: 60 },
                { label: '6 hours', minutes: 360 },
                { label: '24 hours', minutes: 1440 }
              ].map(opt => (
                <button
                  key={opt.minutes}
                  type="button"
                  onClick={() => setTtlMinutes(opt.minutes)}
                  className={`py-1.5 px-3 rounded-lg border font-mono text-xs transition-all ${
                    ttlMinutes === opt.minutes
                      ? 'border-amber-500 bg-amber-500/10 text-amber-300 font-semibold'
                      : 'border-slate-800 bg-slate-900 text-slate-400 hover:text-white'
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          {/* Security Guarantee notice */}
          <div className="rounded-lg border border-amber-500/20 bg-amber-950/20 p-3 flex items-start gap-2.5">
            <ShieldCheck className="h-4 w-4 text-amber-400 shrink-0 mt-0.5" />
            <p className="text-[11px] text-amber-300/90 leading-relaxed">
              Ephemeral user will be provisioned directly in the backend target. Upon TTL expiry or manual revocation, AegisVault automatically terminates all active sessions and drops the role.
            </p>
          </div>

          <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-3 py-1.5 text-slate-400 hover:text-white"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-1.5 font-semibold text-slate-900 bg-amber-400 hover:bg-amber-300 rounded-lg transition-colors"
            >
              Issue Ephemeral Lease
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
