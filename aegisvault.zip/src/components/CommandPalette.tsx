import React, { useState, useEffect } from 'react';
import { useVault } from '../context/VaultContext';
import { 
  Search, 
  Key, 
  Zap, 
  RotateCw, 
  History, 
  Cpu, 
  Terminal, 
  ShieldCheck, 
  ArrowRight,
  Folder
} from 'lucide-react';

interface CommandPaletteProps {
  onOpenNewSecretModal: () => void;
  onOpenDynamicModal: () => void;
  onOpenShamirModal: () => void;
}

export const CommandPalette: React.FC<CommandPaletteProps> = ({
  onOpenNewSecretModal,
  onOpenDynamicModal,
  onOpenShamirModal
}) => {
  const { 
    isCommandPaletteOpen, 
    setIsCommandPaletteOpen, 
    secrets, 
    setCurrentTab, 
    setSelectedEnv,
    rotateSecret,
    sealVault,
    cryptoState
  } = useVault();

  const [query, setQuery] = useState('');

  // Global keyboard listener for Command+K / Ctrl+K and Esc
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setIsCommandPaletteOpen(true);
      }
      if (e.key === 'Escape' && isCommandPaletteOpen) {
        setIsCommandPaletteOpen(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isCommandPaletteOpen, setIsCommandPaletteOpen]);

  if (!isCommandPaletteOpen) return null;

  const filteredSecrets = secrets.filter(s => 
    s.name.toLowerCase().includes(query.toLowerCase()) ||
    s.path.toLowerCase().includes(query.toLowerCase()) ||
    s.description.toLowerCase().includes(query.toLowerCase())
  ).slice(0, 5);

  const actions = [
    {
      id: 'new-secret',
      title: 'Provision New Secret',
      category: 'Actions',
      icon: Key,
      run: () => {
        setIsCommandPaletteOpen(false);
        onOpenNewSecretModal();
      }
    },
    {
      id: 'mint-lease',
      title: 'Mint Dynamic Ephemeral Lease (PostgreSQL / AWS / Redis)',
      category: 'Actions',
      icon: Zap,
      run: () => {
        setIsCommandPaletteOpen(false);
        onOpenDynamicModal();
      }
    },
    {
      id: 'shamir',
      title: cryptoState.isSealed ? 'Unseal Vault with Shamir Custodian Shares' : 'Seal Vault Master Key',
      category: 'Security',
      icon: ShieldCheck,
      run: () => {
        setIsCommandPaletteOpen(false);
        if (cryptoState.isSealed) {
          onOpenShamirModal();
        } else {
          sealVault();
        }
      }
    },
    {
      id: 'tab-audit',
      title: 'Inspect Tamper-Evident Audit Ledger (SHA-256 Chain)',
      category: 'Navigation',
      icon: History,
      run: () => {
        setIsCommandPaletteOpen(false);
        setCurrentTab('audit');
      }
    },
    {
      id: 'tab-cli',
      title: 'Launch CLI Playground & SDK Code Generator',
      category: 'Navigation',
      icon: Terminal,
      run: () => {
        setIsCommandPaletteOpen(false);
        setCurrentTab('cli-sdk');
      }
    },
    {
      id: 'tab-tokens',
      title: 'Manage Machine Service Tokens & Scoped RBAC',
      category: 'Navigation',
      icon: Cpu,
      run: () => {
        setIsCommandPaletteOpen(false);
        setCurrentTab('tokens');
      }
    },
    {
      id: 'env-prod',
      title: 'Switch View to Production Environment',
      category: 'Environments',
      icon: Folder,
      run: () => {
        setSelectedEnv('production');
        setIsCommandPaletteOpen(false);
        setCurrentTab('secrets');
      }
    },
    {
      id: 'env-staging',
      title: 'Switch View to Staging Environment',
      category: 'Environments',
      icon: Folder,
      run: () => {
        setSelectedEnv('staging');
        setIsCommandPaletteOpen(false);
        setCurrentTab('secrets');
      }
    }
  ];

  const matchedActions = actions.filter(a => 
    a.title.toLowerCase().includes(query.toLowerCase()) || 
    a.category.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <div 
      className="fixed inset-0 z-50 flex items-start justify-center pt-20 bg-black/75 backdrop-blur-sm p-4"
      onClick={() => setIsCommandPaletteOpen(false)}
    >
      <div 
        className="w-full max-w-xl rounded-xl border border-slate-800 bg-[#0F172A] shadow-2xl overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Search Input Bar */}
        <div className="flex items-center gap-3 px-4 py-3 border-b border-slate-800">
          <Search className="h-4 w-4 text-cyan-400" />
          <input
            autoFocus
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Type a command, search secrets, or jump to view..."
            className="flex-1 bg-transparent text-sm text-slate-100 placeholder:text-slate-500 outline-none"
          />
          <kbd className="px-1.5 py-0.5 text-[10px] font-mono text-slate-400 bg-slate-800 rounded border border-slate-700">
            ESC
          </kbd>
        </div>

        {/* Results List */}
        <div className="max-h-96 overflow-y-auto p-2 space-y-4 text-xs">
          {/* Matched Secrets */}
          {filteredSecrets.length > 0 && (
            <div>
              <div className="px-2 py-1 text-[10px] font-mono uppercase text-slate-500 font-semibold">
                Secrets & Keys
              </div>
              <div className="space-y-1 mt-1">
                {filteredSecrets.map(sec => (
                  <div
                    key={sec.id}
                    onClick={() => {
                      setIsCommandPaletteOpen(false);
                      setCurrentTab('secrets');
                    }}
                    className="flex items-center justify-between p-2 rounded-lg hover:bg-slate-800 text-slate-300 hover:text-white cursor-pointer group transition-colors"
                  >
                    <div className="flex items-center gap-2">
                      <Key className="h-3.5 w-3.5 text-cyan-400" />
                      <span className="font-mono font-semibold">{sec.name}</span>
                      <span className="text-slate-500 font-mono text-[11px]">{sec.path}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-mono uppercase text-slate-500">{sec.environment}</span>
                      <ArrowRight className="h-3.5 w-3.5 text-slate-600 group-hover:text-cyan-400" />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Quick Actions & Navigation */}
          {matchedActions.length > 0 && (
            <div>
              <div className="px-2 py-1 text-[10px] font-mono uppercase text-slate-500 font-semibold">
                Commands & Shortcuts
              </div>
              <div className="space-y-1 mt-1">
                {matchedActions.map(action => {
                  const Icon = action.icon;
                  return (
                    <div
                      key={action.id}
                      onClick={action.run}
                      className="flex items-center justify-between p-2 rounded-lg hover:bg-slate-800 text-slate-300 hover:text-white cursor-pointer group transition-colors"
                    >
                      <div className="flex items-center gap-2.5">
                        <div className="p-1 rounded bg-slate-900 border border-slate-800 text-cyan-400">
                          <Icon className="h-3.5 w-3.5" />
                        </div>
                        <span>{action.title}</span>
                      </div>
                      <span className="text-[10px] text-slate-500 font-mono">{action.category}</span>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {filteredSecrets.length === 0 && matchedActions.length === 0 && (
            <div className="py-8 text-center text-slate-500">
              No matching commands or secrets found for "{query}".
            </div>
          )}
        </div>

        {/* Footer shortcuts helper */}
        <div className="px-4 py-2 border-t border-slate-800/80 bg-slate-950/60 flex items-center justify-between text-[11px] text-slate-500">
          <div className="flex items-center gap-3">
            <span><strong>↑↓</strong> to navigate</span>
            <span><strong>↵</strong> to select</span>
          </div>
          <span className="font-mono text-cyan-400/80">AegisVault Command Mesh</span>
        </div>
      </div>
    </div>
  );
};
