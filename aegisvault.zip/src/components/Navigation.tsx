import React from 'react';
import { useVault } from '../context/VaultContext';
import { NavTab } from '../types/vault';
import { 
  KeyRound, 
  Zap, 
  RotateCw, 
  History, 
  Cpu, 
  Terminal, 
  ShieldCheck,
  AlertTriangle
} from 'lucide-react';

export const Navigation: React.FC = () => {
  const { currentTab, setCurrentTab, secrets, dynamicLeases, auditLogs, cryptoState } = useVault();

  // Compute counters
  const activeSecretsCount = secrets.length;
  const overdueRotationsCount = secrets.filter(
    s => s.rotationPolicy.healthStatus === 'overdue' || s.rotationPolicy.healthStatus === 'due'
  ).length;
  const activeLeasesCount = dynamicLeases.filter(l => l.status === 'active').length;

  const tabs: { id: NavTab; label: string; icon: React.ComponentType<{ className?: string }>; badge?: number; badgeVariant?: 'alert' | 'neutral' }[] = [
    { 
      id: 'secrets', 
      label: 'Secrets & Keys', 
      icon: KeyRound,
      badge: activeSecretsCount,
      badgeVariant: 'neutral'
    },
    { 
      id: 'dynamic', 
      label: 'Dynamic Leases', 
      icon: Zap,
      badge: activeLeasesCount,
      badgeVariant: 'neutral'
    },
    { 
      id: 'rotation', 
      label: 'Rotation Engine', 
      icon: RotateCw,
      badge: overdueRotationsCount > 0 ? overdueRotationsCount : undefined,
      badgeVariant: overdueRotationsCount > 0 ? 'alert' : 'neutral'
    },
    { 
      id: 'audit', 
      label: 'Audit Ledger', 
      icon: History,
      badge: auditLogs.length,
      badgeVariant: 'neutral'
    },
    { 
      id: 'tokens', 
      label: 'Service Tokens', 
      icon: Cpu 
    },
    { 
      id: 'cli-sdk', 
      label: 'CLI & SDKs', 
      icon: Terminal 
    },
    { 
      id: 'crypto', 
      label: 'Master Key & Shamir', 
      icon: cryptoState.isSealed ? AlertTriangle : ShieldCheck,
      badgeVariant: cryptoState.isSealed ? 'alert' : 'neutral'
    }
  ];

  return (
    <nav className="w-full border-b border-slate-800 bg-[#090D16]/50 px-4 sm:px-6">
      <div className="mx-auto flex max-w-7xl items-center gap-1 overflow-x-auto py-2 no-scrollbar">
        {tabs.map(tab => {
          const Icon = tab.icon;
          const isActive = currentTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setCurrentTab(tab.id)}
              className={`flex items-center gap-2 px-3 py-1.5 rounded-md text-xs font-medium transition-all whitespace-nowrap cursor-pointer ${
                isActive
                  ? 'bg-slate-800 text-white shadow-sm border border-slate-700/60'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/40'
              }`}
            >
              <Icon className={`h-3.5 w-3.5 ${isActive ? 'text-cyan-400' : 'text-slate-500'}`} />
              <span>{tab.label}</span>

              {tab.badge !== undefined && (
                <span 
                  className={`text-[10px] font-mono px-1.5 py-0.2 rounded-full tabular-nums ${
                    tab.badgeVariant === 'alert'
                      ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                      : isActive 
                        ? 'bg-slate-700 text-slate-300' 
                        : 'bg-slate-800/80 text-slate-500'
                  }`}
                >
                  {tab.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
};
