import React, { useState } from 'react';
import { useVault } from '../context/VaultContext';
import { Secret, RotationStrategy } from '../types/vault';
import { formatCountdown, formatRelativeTime } from '../lib/cryptoUtils';
import { 
  RotateCw, 
  CheckCircle2, 
  AlertTriangle, 
  Clock, 
  Settings, 
  Zap, 
  Send, 
  Database, 
  Cloud, 
  Key, 
  ShieldCheck,
  Check
} from 'lucide-react';

export const RotationHub: React.FC = () => {
  const { 
    secrets, 
    rotateSecret, 
    batchRotateDueSecrets, 
    updateRotationPolicy, 
    addToast,
    cryptoState
  } = useVault();

  const [isRotatingBatch, setIsRotatingBatch] = useState(false);
  const [editingPolicySecret, setEditingPolicySecret] = useState<Secret | null>(null);
  const [policyInterval, setPolicyInterval] = useState(30);
  const [policyStrategy, setPolicyStrategy] = useState<RotationStrategy>('crypto-random');
  const [policyAuto, setPolicyAuto] = useState(true);
  const [policyWebhook, setPolicyWebhook] = useState('');
  const [testingWebhook, setTestingWebhook] = useState(false);
  const [webhookTested, setWebhookTested] = useState(false);

  // Metrics
  const autoSecrets = secrets.filter(s => s.rotationPolicy.enabled);
  const overdueSecrets = secrets.filter(s => s.rotationPolicy.healthStatus === 'overdue');
  const dueSecrets = secrets.filter(s => s.rotationPolicy.healthStatus === 'due');
  const healthySecrets = secrets.filter(s => s.rotationPolicy.healthStatus === 'healthy' && s.rotationPolicy.enabled);

  const handleBatchRotate = async () => {
    if (cryptoState.isSealed) {
      addToast({
        type: 'error',
        title: 'Vault Sealed',
        message: 'Cannot rotate secrets while master key is sealed.'
      });
      return;
    }
    setIsRotatingBatch(true);
    try {
      const count = await batchRotateDueSecrets();
      addToast({
        type: 'success',
        title: 'Batch Rotation Complete',
        message: `Successfully rotated ${count} overdue secrets across environments.`
      });
    } finally {
      setIsRotatingBatch(false);
    }
  };

  const openPolicyEditor = (secret: Secret) => {
    setEditingPolicySecret(secret);
    setPolicyInterval(secret.rotationPolicy.intervalDays);
    setPolicyStrategy(secret.rotationPolicy.strategy);
    setPolicyAuto(secret.rotationPolicy.autoRotate);
    setPolicyWebhook(secret.rotationPolicy.webhookUrl || '');
    setWebhookTested(false);
  };

  const handleSavePolicy = () => {
    if (!editingPolicySecret) return;
    updateRotationPolicy(editingPolicySecret.id, {
      enabled: true,
      intervalDays: policyInterval,
      strategy: policyStrategy,
      autoRotate: policyAuto,
      webhookUrl: policyWebhook.trim() || undefined
    });
    setEditingPolicySecret(null);
  };

  const handleTestWebhook = () => {
    setTestingWebhook(true);
    setTimeout(() => {
      setTestingWebhook(false);
      setWebhookTested(true);
      addToast({
        type: 'success',
        title: 'Webhook Handshake Verified',
        message: 'HTTP 200 OK — HMAC-SHA256 signature accepted by target endpoint.'
      });
    }, 1200);
  };

  return (
    <div className="space-y-6">
      {/* Top Header & Batch Action */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-sm font-semibold text-slate-100 flex items-center gap-2">
            <RotateCw className="h-4 w-4 text-cyan-400" />
            Automated Secret Rotation Engine
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Zero-downtime automated rotation with dual-version grace periods, database role swapping, and AWS IAM lifecycle hooks.
          </p>
        </div>

        {overdueSecrets.length + dueSecrets.length > 0 && (
          <button
            onClick={handleBatchRotate}
            disabled={isRotatingBatch}
            className="flex items-center gap-2 px-3.5 py-1.5 text-xs font-semibold text-slate-900 bg-amber-400 hover:bg-amber-300 rounded-lg transition-colors cursor-pointer shrink-0 disabled:opacity-50"
          >
            <RotateCw className={`h-3.5 w-3.5 ${isRotatingBatch ? 'animate-spin' : ''}`} />
            <span>
              {isRotatingBatch ? 'Rotating Overdue Secrets...' : `Rotate All Due (${overdueSecrets.length + dueSecrets.length})`}
            </span>
          </button>
        )}
      </div>

      {/* Rotation Status Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="rounded-xl border border-slate-800 bg-slate-900/40 p-4 space-y-1">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Automated Policies</span>
            <ShieldCheck className="h-4 w-4 text-cyan-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-white">
            {autoSecrets.length} <span className="text-xs text-slate-500 font-normal">/ {secrets.length} secrets</span>
          </div>
          <p className="text-[11px] text-slate-500">
            Managed under active rotation policies
          </p>
        </div>

        <div className="rounded-xl border border-emerald-500/20 bg-emerald-950/10 p-4 space-y-1">
          <div className="flex items-center justify-between text-xs text-emerald-400">
            <span>Healthy Schedule</span>
            <CheckCircle2 className="h-4 w-4" />
          </div>
          <div className="text-2xl font-bold font-mono text-emerald-300">
            {healthySecrets.length}
          </div>
          <p className="text-[11px] text-emerald-400/70">
            Within nominal validity window
          </p>
        </div>

        <div className="rounded-xl border border-amber-500/20 bg-amber-950/10 p-4 space-y-1">
          <div className="flex items-center justify-between text-xs text-amber-400">
            <span>Due Soon (&lt;48h)</span>
            <Clock className="h-4 w-4" />
          </div>
          <div className="text-2xl font-bold font-mono text-amber-300">
            {dueSecrets.length}
          </div>
          <p className="text-[11px] text-amber-400/70">
            Scheduled for automatic renewal
          </p>
        </div>

        <div className="rounded-xl border border-rose-500/20 bg-rose-950/10 p-4 space-y-1">
          <div className="flex items-center justify-between text-xs text-rose-400">
            <span>Overdue Rotations</span>
            <AlertTriangle className="h-4 w-4" />
          </div>
          <div className="text-2xl font-bold font-mono text-rose-300">
            {overdueSecrets.length}
          </div>
          <p className="text-[11px] text-rose-400/70">
            Requires immediate compliance rotation
          </p>
        </div>
      </div>

      {/* Rotation Schedule Table */}
      <div className="space-y-3">
        <h3 className="text-xs font-semibold text-slate-200 uppercase tracking-wider font-mono">
          Secret Rotation Schedules & Strategy
        </h3>

        <div className="rounded-xl border border-slate-800/80 bg-slate-900/40 overflow-hidden">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-800/80 bg-slate-950/60 text-slate-400 text-[11px] uppercase tracking-wider font-mono">
                <th className="py-2.5 px-4 font-medium">Secret</th>
                <th className="py-2.5 px-3 font-medium">Environment</th>
                <th className="py-2.5 px-4 font-medium">Rotation Strategy</th>
                <th className="py-2.5 px-3 font-medium">Cadence</th>
                <th className="py-2.5 px-4 font-medium">Next Scheduled</th>
                <th className="py-2.5 px-3 font-medium">Status</th>
                <th className="py-2.5 px-4 text-right font-medium">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-sans">
              {secrets.map(sec => {
                const isOverdue = sec.rotationPolicy.healthStatus === 'overdue';
                const isDue = sec.rotationPolicy.healthStatus === 'due';
                const countdown = formatCountdown(sec.rotationPolicy.nextRotationAt);

                return (
                  <tr key={sec.id} className="hover:bg-slate-800/30 transition-colors">
                    {/* Secret Name & Path */}
                    <td className="py-3 px-4">
                      <div className="font-mono font-semibold text-slate-100 text-xs">
                        {sec.name}
                      </div>
                      <div className="text-[11px] font-mono text-slate-500">
                        {sec.path}
                      </div>
                    </td>

                    {/* Environment */}
                    <td className="py-3 px-3">
                      <span className="font-mono text-xs capitalize text-slate-300">
                        {sec.environment}
                      </span>
                    </td>

                    {/* Strategy */}
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-1.5">
                        {sec.rotationPolicy.strategy === 'database-role' && <Database className="h-3.5 w-3.5 text-cyan-400" />}
                        {sec.rotationPolicy.strategy === 'aws-iam' && <Cloud className="h-3.5 w-3.5 text-amber-400" />}
                        {sec.rotationPolicy.strategy === 'crypto-random' && <Key className="h-3.5 w-3.5 text-emerald-400" />}
                        {sec.rotationPolicy.strategy === 'webhook-hook' && <Send className="h-3.5 w-3.5 text-purple-400" />}
                        <span className="capitalize text-slate-300">
                          {sec.rotationPolicy.strategy.replace('-', ' ')}
                        </span>
                      </div>
                    </td>

                    {/* Cadence */}
                    <td className="py-3 px-3 font-mono text-slate-400">
                      {sec.rotationPolicy.intervalDays} days
                    </td>

                    {/* Next Scheduled */}
                    <td className="py-3 px-4">
                      <div className="font-mono text-xs tabular-nums text-slate-200">
                        {countdown.label}
                      </div>
                      <div className="text-[10px] text-slate-500 font-mono">
                        Last: {formatRelativeTime(sec.rotationPolicy.lastRotatedAt)}
                      </div>
                    </td>

                    {/* Status */}
                    <td className="py-3 px-3">
                      <span className={`text-[11px] font-mono px-2 py-0.5 rounded ${
                        isOverdue
                          ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                          : isDue
                            ? 'bg-amber-500/10 text-amber-300 border border-amber-500/20'
                            : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                      }`}>
                        {isOverdue ? 'OVERDUE' : isDue ? 'DUE SOON' : 'HEALTHY'}
                      </span>
                    </td>

                    {/* Actions */}
                    <td className="py-3 px-4 text-right whitespace-nowrap">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => rotateSecret(sec.id, 'Manual on-demand rotation')}
                          className="px-2.5 py-1 text-[11px] font-medium text-slate-300 bg-slate-800 hover:text-cyan-300 hover:bg-slate-700 rounded transition-colors cursor-pointer flex items-center gap-1"
                          title="Rotate immediately"
                        >
                          <RotateCw className="h-3 w-3" />
                          <span>Rotate</span>
                        </button>

                        <button
                          onClick={() => openPolicyEditor(sec)}
                          className="p-1 rounded text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
                          title="Configure rotation policy"
                        >
                          <Settings className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Policy Configuration Modal */}
      {editingPolicySecret && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
          <div className="w-full max-w-lg rounded-xl border border-slate-800 bg-[#0F172A] p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Settings className="h-4 w-4 text-cyan-400" />
                Configure Rotation: <span className="font-mono text-cyan-300">{editingPolicySecret.name}</span>
              </h3>
              <button
                onClick={() => setEditingPolicySecret(null)}
                className="text-slate-400 hover:text-white text-xs px-2 py-1 rounded bg-slate-800/80 cursor-pointer"
              >
                Close
              </button>
            </div>

            <div className="space-y-4 text-xs">
              {/* Rotation Cadence */}
              <div>
                <label className="block text-slate-400 mb-1.5 font-medium">Rotation Cadence</label>
                <div className="grid grid-cols-4 gap-2">
                  {[7, 14, 30, 90].map(days => (
                    <button
                      key={days}
                      type="button"
                      onClick={() => setPolicyInterval(days)}
                      className={`py-1.5 px-3 rounded-lg border font-mono text-xs transition-all cursor-pointer ${
                        policyInterval === days
                          ? 'border-cyan-500 bg-cyan-500/10 text-cyan-300 font-semibold'
                          : 'border-slate-800 bg-slate-900 text-slate-400 hover:text-white'
                      }`}
                    >
                      {days} Days
                    </button>
                  ))}
                </div>
              </div>

              {/* Strategy Selector */}
              <div>
                <label className="block text-slate-400 mb-1.5 font-medium">Rotation Strategy</label>
                <div className="space-y-2">
                  {[
                    { id: 'crypto-random', title: 'Cryptographic Entropy (High Entropy API Key)', desc: 'Generates secure 32/48-byte token and replaces active version' },
                    { id: 'database-role', title: 'Database Role Swap (PostgreSQL/MySQL)', desc: 'Creates shadow database user, swaps connection pooling, drops old role' },
                    { id: 'aws-iam', title: 'AWS IAM Key Lifecycle', desc: 'Rotates IAM access keys with temporary overlapping dual-key support' },
                    { id: 'webhook-hook', title: 'Custom Webhook Hook', desc: 'Sends HMAC-signed POST request to your microservice rotation endpoint' }
                  ].map(strat => (
                    <div
                      key={strat.id}
                      onClick={() => setPolicyStrategy(strat.id as any)}
                      className={`p-2.5 rounded-lg border cursor-pointer transition-all ${
                        policyStrategy === strat.id
                          ? 'border-cyan-500/60 bg-cyan-950/20'
                          : 'border-slate-800 bg-slate-900/40 hover:border-slate-700'
                      }`}
                    >
                      <div className="font-semibold text-slate-200">{strat.title}</div>
                      <div className="text-[11px] text-slate-400 mt-0.5">{strat.desc}</div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Webhook URL input if webhook strategy */}
              {policyStrategy === 'webhook-hook' && (
                <div className="space-y-2 pt-1">
                  <label className="block text-slate-400 font-medium">Rotation Webhook URL</label>
                  <div className="flex gap-2">
                    <input
                      type="url"
                      value={policyWebhook}
                      onChange={(e) => setPolicyWebhook(e.target.value)}
                      placeholder="https://api.internal.corp/v1/rotate-hook"
                      className="flex-1 rounded-lg border border-slate-800 bg-slate-950 px-3 py-1.5 text-xs text-slate-200 outline-none focus:border-cyan-500 font-mono"
                    />
                    <button
                      type="button"
                      onClick={handleTestWebhook}
                      disabled={testingWebhook || !policyWebhook}
                      className="px-3 py-1.5 text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg transition-colors disabled:opacity-50 cursor-pointer flex items-center gap-1"
                    >
                      {testingWebhook ? 'Pinging...' : webhookTested ? <Check className="h-3 w-3 text-emerald-400" /> : 'Ping Test'}
                    </button>
                  </div>
                </div>
              )}

              {/* Auto-rotate switch */}
              <div className="flex items-center justify-between p-3 rounded-lg border border-slate-800 bg-slate-950">
                <div>
                  <div className="font-semibold text-slate-200">Automated Background Execution</div>
                  <div className="text-[11px] text-slate-400">Trigger rotation automatically when cadence threshold is reached</div>
                </div>
                <button
                  type="button"
                  onClick={() => setPolicyAuto(!policyAuto)}
                  className={`w-11 h-6 rounded-full transition-colors relative cursor-pointer ${
                    policyAuto ? 'bg-cyan-500' : 'bg-slate-700'
                  }`}
                >
                  <div className={`w-4 h-4 rounded-full bg-white transition-transform absolute top-1 ${
                    policyAuto ? 'left-6' : 'left-1'
                  }`} />
                </button>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-800">
              <button
                onClick={() => setEditingPolicySecret(null)}
                className="px-3 py-1.5 text-xs text-slate-400 hover:text-white"
              >
                Cancel
              </button>
              <button
                onClick={handleSavePolicy}
                className="px-4 py-1.5 text-xs font-semibold text-slate-900 bg-cyan-400 rounded-lg hover:bg-cyan-300 transition-colors"
              >
                Save Rotation Policy
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
