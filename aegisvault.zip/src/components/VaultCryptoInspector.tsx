import React from 'react';
import { useVault } from '../context/VaultContext';
import { DEFAULT_SHAMIR_SHARES } from '../lib/cryptoUtils';
import { 
  ShieldCheck, 
  ShieldAlert, 
  Key, 
  Lock, 
  Unlock, 
  Layers, 
  Cpu, 
  Hash, 
  FileCode,
  CheckCircle2,
  AlertTriangle
} from 'lucide-react';

interface VaultCryptoInspectorProps {
  onOpenShamirModal: () => void;
}

export const VaultCryptoInspector: React.FC<VaultCryptoInspectorProps> = ({ onOpenShamirModal }) => {
  const { cryptoState, sealVault } = useVault();

  return (
    <div className="space-y-6">
      {/* Hero Security Overview */}
      <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-5 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              {cryptoState.isSealed ? (
                <ShieldAlert className="h-5 w-5 text-rose-400" />
              ) : (
                <ShieldCheck className="h-5 w-5 text-emerald-400" />
              )}
              <h2 className="text-sm font-semibold text-slate-100">
                Envelope Encryption & Shamir Key Hierarchy
              </h2>
              <span className={`text-[10px] font-mono px-2 py-0.5 rounded border ${
                cryptoState.isSealed 
                  ? 'bg-rose-950/60 text-rose-300 border-rose-800/40' 
                  : 'bg-emerald-950/60 text-emerald-300 border-emerald-800/40'
              }`}>
                {cryptoState.isSealed ? 'VAULT SEALED' : 'VAULT OPERATIONAL (UNSEALED)'}
              </span>
            </div>
            <p className="text-xs text-slate-400 max-w-2xl leading-relaxed">
              AegisVault implements Shamir's Secret Sharing (SLIP-0039) over finite fields GF(256). In-memory AES-256-GCM data encryption keys (DEKs) are zeroized when sealed.
            </p>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            {cryptoState.isSealed ? (
              <button
                onClick={onOpenShamirModal}
                className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-rose-500 hover:bg-rose-600 rounded-lg transition-colors cursor-pointer"
              >
                <Unlock className="h-3.5 w-3.5" />
                <span>Unseal with Shamir Shares</span>
              </button>
            ) : (
              <button
                onClick={() => {
                  if (confirm('Seal vault now? All decrypted secrets will be locked immediately.')) {
                    sealVault();
                  }
                }}
                className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-rose-300 bg-rose-950/40 border border-rose-800/60 hover:bg-rose-900/60 rounded-lg transition-colors cursor-pointer"
              >
                <Lock className="h-3.5 w-3.5" />
                <span>Seal Vault Master Key</span>
              </button>
            )}
          </div>
        </div>

        {/* Security Parameters Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 pt-2">
          <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 space-y-1">
            <div className="text-[10px] uppercase font-mono text-slate-500">Envelope Algorithm</div>
            <div className="text-xs font-bold font-mono text-slate-200">{cryptoState.algorithm}</div>
            <div className="text-[10px] text-slate-500">Authenticated Galois Counter</div>
          </div>

          <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 space-y-1">
            <div className="text-[10px] uppercase font-mono text-slate-500">Shamir Quorum</div>
            <div className="text-xs font-bold font-mono text-cyan-300">
              {cryptoState.shamirThreshold} of {cryptoState.shamirTotalShares} Key Custodians
            </div>
            <div className="text-[10px] text-slate-500">Multi-party threshold</div>
          </div>

          <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 space-y-1">
            <div className="text-[10px] uppercase font-mono text-slate-500">Key Ring Epoch</div>
            <div className="text-xs font-bold font-mono text-slate-200">Epoch #{cryptoState.keyEpoch}</div>
            <div className="text-[10px] text-slate-500">Active root key derivation</div>
          </div>

          <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 space-y-1">
            <div className="text-[10px] uppercase font-mono text-slate-500">Zero-Knowledge State</div>
            <div className="text-xs font-bold font-mono text-emerald-400">Verified Client-Side</div>
            <div className="text-[10px] text-slate-500">No raw keys touch persistence</div>
          </div>
        </div>
      </div>

      {/* Shamir Key Custodian Shares Demonstration */}
      <div className="space-y-3">
        <div>
          <h3 className="text-xs font-semibold text-slate-200 uppercase tracking-wider font-mono">
            Shamir Custodian Key Shares (SLIP-0039 Multi-Party)
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">
            Any 3 of these 5 distributed shards are sufficient to mathematically reconstruct the master root AES ring.
          </p>
        </div>

        <div className="space-y-2">
          {DEFAULT_SHAMIR_SHARES.map((share, idx) => {
            const isRegistered = cryptoState.submittedShares.includes(share);
            return (
              <div 
                key={share}
                className="flex items-center justify-between p-3 rounded-lg border border-slate-800 bg-slate-900/40 text-xs font-mono"
              >
                <div className="flex items-center gap-3">
                  <span className="text-slate-500 font-bold">Shard #{idx + 1}</span>
                  <span className="text-slate-300">{share}</span>
                </div>

                <div className="flex items-center gap-2">
                  {cryptoState.isSealed ? (
                    <button
                      onClick={onOpenShamirModal}
                      className="px-2 py-1 text-[11px] rounded bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-slate-700 cursor-pointer"
                    >
                      Use Shard to Unseal
                    </button>
                  ) : (
                    <span className="text-[10px] text-emerald-400 flex items-center gap-1">
                      <CheckCircle2 className="h-3 w-3" />
                      <span>Armed & Guarded</span>
                    </span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
