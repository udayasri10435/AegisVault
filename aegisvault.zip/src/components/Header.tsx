import React from 'react';
import { useVault } from '../context/VaultContext';
import { Environment } from '../types/vault';
import { 
  ShieldCheck, 
  ShieldAlert, 
  Search, 
  Plus, 
  Zap, 
  Key, 
  Terminal
} from 'lucide-react';

interface HeaderProps {
  onOpenNewSecretModal: () => void;
  onOpenDynamicModal: () => void;
  onOpenShamirModal: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  onOpenNewSecretModal,
  onOpenDynamicModal,
  onOpenShamirModal
}) => {
  const { 
    selectedEnv, 
    setSelectedEnv, 
    cryptoState, 
    sealVault, 
    setIsCommandPaletteOpen,
    searchQuery,
    setSearchQuery,
    setCurrentTab
  } = useVault();

  const envs: { id: Environment | 'all'; label: string }[] = [
    { id: 'production', label: 'Production' },
    { id: 'staging', label: 'Staging' },
    { id: 'development', label: 'Development' },
    { id: 'all', label: 'All Environments' }
  ];

  return (
    <header className="sticky top-0 z-40 w-full border-b border-slate-800/80 bg-[#090D16]/90 backdrop-blur-md px-4 sm:px-6 py-3 transition-colors">
      <div className="mx-auto flex max-w-7xl items-center justify-between gap-4">
        {/* Zone 1: Brand wordmark */}
        <div className="flex items-center gap-6 shrink-0">
          <div className="flex items-center gap-2.5 cursor-pointer" onClick={() => setCurrentTab('secrets')}>
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-cyan-500/10 border border-cyan-500/30 text-cyan-400">
              <Key className="h-4 w-4" />
            </div>
            <div className="flex flex-col">
              <span className="text-base font-bold tracking-tight text-white flex items-center gap-1.5">
                AegisVault
                <span className="text-[10px] font-mono font-normal text-cyan-400/80 uppercase tracking-wider px-1.5 py-0.2 rounded border border-cyan-500/20 bg-cyan-950/40">
                  v2.8
                </span>
              </span>
            </div>
          </div>

          {/* Environment segmented switcher */}
          <div className="hidden lg:flex items-center rounded-lg border border-slate-800 bg-slate-900/60 p-0.5 text-xs">
            {envs.map(env => (
              <button
                key={env.id}
                onClick={() => setSelectedEnv(env.id)}
                className={`px-3 py-1 font-medium rounded-md transition-all whitespace-nowrap ${
                  selectedEnv === env.id
                    ? 'bg-slate-800 text-cyan-300 shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {env.label}
              </button>
            ))}
          </div>
        </div>

        {/* Zone 2: Search input and Command Palette trigger */}
        <div className="flex-1 max-w-md mx-2">
          <div 
            onClick={() => setIsCommandPaletteOpen(true)}
            className="flex items-center gap-2 px-3 py-1.5 rounded-lg border border-slate-800 bg-slate-900/50 hover:border-slate-700 text-xs text-slate-400 cursor-pointer group transition-all"
          >
            <Search className="h-3.5 w-3.5 text-slate-500 group-hover:text-cyan-400" />
            <input
              type="text"
              placeholder="Search secrets, leases, paths, audit events..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onClick={(e) => e.stopPropagation()}
              className="bg-transparent border-none outline-none text-slate-200 placeholder:text-slate-500 text-xs w-full"
            />
            <kbd className="hidden sm:inline-flex items-center gap-0.5 rounded border border-slate-700 bg-slate-800/80 px-1.5 text-[10px] font-mono text-slate-400">
              ⌘K
            </kbd>
          </div>
        </div>

        {/* Zone 3: Actions & Vault Cryptographic Status */}
        <div className="flex items-center gap-2 sm:gap-3 shrink-0">
          {/* Vault Crypto Lock/Unlock Status */}
          {cryptoState.isSealed ? (
            <button
              onClick={onOpenShamirModal}
              className="flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-medium border border-rose-500/40 bg-rose-500/10 text-rose-300 hover:bg-rose-500/20 transition-all cursor-pointer"
              title="Vault is Sealed. Click to unseal with Shamir key shares."
            >
              <ShieldAlert className="h-3.5 w-3.5 text-rose-400 animate-pulse" />
              <span className="font-mono">SEALED (3/5)</span>
            </button>
          ) : (
            <button
              onClick={() => {
                if (confirm('Seal this vault now? All in-memory cryptographic keys will be purged until 3 of 5 Shamir shares are submitted.')) {
                  sealVault();
                }
              }}
              className="group flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-medium border border-emerald-500/30 bg-emerald-500/10 text-emerald-300 hover:border-rose-500/40 hover:bg-rose-500/10 hover:text-rose-300 transition-all"
              title="Vault is Unsealed and active with AES-256-GCM. Click to Seal."
            >
              <ShieldCheck className="h-3.5 w-3.5 text-emerald-400 group-hover:hidden" />
              <ShieldAlert className="h-3.5 w-3.5 text-rose-400 hidden group-hover:inline" />
              <span className="font-mono text-[11px] group-hover:hidden">UNSEALED</span>
              <span className="font-mono text-[11px] hidden group-hover:inline">SEAL VAULT</span>
            </button>
          )}

          {/* Quick Dynamic Credential Button */}
          <button
            onClick={onOpenDynamicModal}
            className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-300 bg-slate-800/80 border border-slate-700 rounded-lg hover:border-cyan-500/50 hover:text-cyan-300 transition-all"
          >
            <Zap className="h-3.5 w-3.5 text-amber-400" />
            <span>Mint Lease</span>
          </button>

          {/* New Secret Primary Action */}
          <button
            onClick={onOpenNewSecretModal}
            className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-slate-900 bg-cyan-400 rounded-lg hover:bg-cyan-300 shadow-sm transition-all whitespace-nowrap cursor-pointer"
          >
            <Plus className="h-3.5 w-3.5 stroke-[2.5]" />
            <span>New Secret</span>
          </button>
        </div>
      </div>
    </header>
  );
};
