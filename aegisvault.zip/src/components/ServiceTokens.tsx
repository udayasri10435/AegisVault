import React, { useState } from 'react';
import { useVault } from '../context/VaultContext';
import { Environment } from '../types/vault';
import { formatRelativeTime } from '../lib/cryptoUtils';
import { 
  Cpu, 
  Plus, 
  Copy, 
  Check, 
  ShieldAlert, 
  Trash2, 
  Key, 
  Lock, 
  CheckCircle2, 
  ShieldCheck,
  AlertCircle
} from 'lucide-react';

export const ServiceTokens: React.FC = () => {
  const { serviceTokens, createServiceToken, revokeServiceToken, addToast } = useVault();

  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [tokenName, setTokenName] = useState('');
  const [envScope, setEnvScope] = useState<Environment | 'all'>('production');
  const [pathPattern, setPathPattern] = useState('*');
  const [policies, setPolicies] = useState<('read' | 'write' | 'rotate' | 'dynamic_issue')[]>(['read']);
  const [createdRawToken, setCreatedRawToken] = useState<string | null>(null);
  const [copiedToken, setCopiedToken] = useState(false);

  const togglePolicy = (policy: 'read' | 'write' | 'rotate' | 'dynamic_issue') => {
    setPolicies(prev => 
      prev.includes(policy) ? prev.filter(p => p !== policy) : [...prev, policy]
    );
  };

  const handleCreate = () => {
    if (!tokenName.trim() || policies.length === 0) return;
    const { rawToken } = createServiceToken(tokenName.trim(), envScope, pathPattern, policies);
    setCreatedRawToken(rawToken);
  };

  const handleCopyRawToken = () => {
    if (!createdRawToken) return;
    navigator.clipboard.writeText(createdRawToken);
    setCopiedToken(true);
    addToast({
      type: 'info',
      title: 'Token Copied',
      message: 'Store this token securely in your CI/CD runner secret store.'
    });
    setTimeout(() => setCopiedToken(false), 2000);
  };

  const closeCreateModal = () => {
    setIsCreateModalOpen(false);
    setCreatedRawToken(null);
    setTokenName('');
    setPolicies(['read']);
    setPathPattern('*');
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-sm font-semibold text-slate-100 flex items-center gap-2">
            <Cpu className="h-4 w-4 text-cyan-400" />
            Machine-to-Machine Service Tokens
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Scoped access tokens for CI/CD runners, Kubernetes operators, Terraform pipelines, and backend microservices.
          </p>
        </div>

        <button
          onClick={() => setIsCreateModalOpen(true)}
          className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-slate-900 bg-cyan-400 hover:bg-cyan-300 rounded-lg transition-colors cursor-pointer shrink-0"
        >
          <Plus className="h-3.5 w-3.5 stroke-[2.5]" />
          <span>Mint Service Token</span>
        </button>
      </div>

      {/* Service Tokens Table */}
      <div className="rounded-xl border border-slate-800/80 bg-slate-900/40 overflow-hidden">
        <table className="w-full text-left text-xs border-collapse">
          <thead>
            <tr className="border-b border-slate-800/80 bg-slate-950/60 text-slate-400 text-[11px] uppercase tracking-wider font-mono">
              <th className="py-2.5 px-4 font-medium">Token Name & Prefix</th>
              <th className="py-2.5 px-3 font-medium">Environment</th>
              <th className="py-2.5 px-4 font-medium">Path Scope</th>
              <th className="py-2.5 px-4 font-medium">Permissions</th>
              <th className="py-2.5 px-3 font-medium">Last Used</th>
              <th className="py-2.5 px-3 font-medium">Status</th>
              <th className="py-2.5 px-4 text-right font-medium">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60 font-sans">
            {serviceTokens.map(tok => {
              const isActive = tok.status === 'active';

              return (
                <tr key={tok.id} className="hover:bg-slate-800/30 transition-colors">
                  <td className="py-3 px-4">
                    <div className="font-semibold text-slate-100 text-xs">
                      {tok.name}
                    </div>
                    <div className="font-mono text-[11px] text-slate-500 mt-0.5">
                      {tok.tokenPrefix}...
                    </div>
                  </td>

                  <td className="py-3 px-3">
                    <span className="font-mono text-xs capitalize text-slate-300">
                      {tok.environmentScope}
                    </span>
                  </td>

                  <td className="py-3 px-4 font-mono text-xs text-slate-300">
                    <span className="bg-slate-950 px-2 py-0.5 rounded border border-slate-800">
                      {tok.pathPattern}
                    </span>
                  </td>

                  <td className="py-3 px-4">
                    <div className="flex flex-wrap gap-1">
                      {tok.policies.map(p => (
                        <span 
                          key={p}
                          className="font-mono text-[10px] px-1.5 py-0.2 rounded bg-slate-800 text-cyan-300 border border-slate-700"
                        >
                          {p}
                        </span>
                      ))}
                    </div>
                  </td>

                  <td className="py-3 px-3 text-slate-400 font-mono text-xs whitespace-nowrap">
                    {tok.lastUsedAt === 'Never' ? (
                      <span className="text-slate-500">Never</span>
                    ) : (
                      formatRelativeTime(tok.lastUsedAt)
                    )}
                  </td>

                  <td className="py-3 px-3">
                    <span className={`text-[11px] font-mono px-2 py-0.5 rounded ${
                      isActive 
                        ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' 
                        : 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                    }`}>
                      {tok.status.toUpperCase()}
                    </span>
                  </td>

                  <td className="py-3 px-4 text-right">
                    {isActive ? (
                      <button
                        onClick={() => {
                          if (confirm(`Revoke token "${tok.name}" immediately? Services using this token will fail authentication.`)) {
                            revokeServiceToken(tok.id);
                          }
                        }}
                        className="p-1 rounded text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 transition-colors cursor-pointer"
                        title="Revoke Token"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    ) : (
                      <span className="text-slate-600 text-xs">Revoked</span>
                    )}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Mint Service Token Modal */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
          <div className="w-full max-w-lg rounded-xl border border-slate-800 bg-[#0F172A] p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Cpu className="h-4 w-4 text-cyan-400" />
                Mint Scoped Service Token
              </h3>
              <button
                onClick={closeCreateModal}
                className="text-slate-400 hover:text-white text-xs px-2 py-1 rounded bg-slate-800/80 cursor-pointer"
              >
                Close
              </button>
            </div>

            {createdRawToken ? (
              <div className="space-y-4">
                <div className="rounded-lg border border-emerald-500/30 bg-emerald-950/20 p-4 space-y-2">
                  <div className="flex items-center gap-2 text-emerald-400 font-semibold text-xs">
                    <CheckCircle2 className="h-4 w-4" />
                    <span>Service Token Generated Successfully</span>
                  </div>
                  <p className="text-xs text-slate-300">
                    Make sure to copy your service token now. For security reasons, you won't be able to see it again.
                  </p>
                  
                  <div className="flex items-center gap-2 bg-slate-950 p-2.5 rounded border border-slate-800 font-mono text-xs text-cyan-300 break-all select-all">
                    <span>{createdRawToken}</span>
                    <button
                      onClick={handleCopyRawToken}
                      className="ml-auto shrink-0 p-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-200"
                    >
                      {copiedToken ? <Check className="h-4 w-4 text-emerald-400" /> : <Copy className="h-4 w-4" />}
                    </button>
                  </div>
                </div>

                <div className="flex justify-end">
                  <button
                    onClick={closeCreateModal}
                    className="px-4 py-1.5 text-xs font-semibold text-slate-900 bg-cyan-400 rounded-lg hover:bg-cyan-300"
                  >
                    Done
                  </button>
                </div>
              </div>
            ) : (
              <div className="space-y-3 text-xs">
                <div>
                  <label className="block text-slate-400 mb-1 font-medium">Token Name</label>
                  <input
                    type="text"
                    value={tokenName}
                    onChange={(e) => setTokenName(e.target.value)}
                    placeholder="e.g. GitHub Actions CI Deployer"
                    className="w-full rounded-lg border border-slate-800 bg-slate-950 px-3 py-2 text-slate-200 outline-none focus:border-cyan-500"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-slate-400 mb-1 font-medium">Environment Scope</label>
                    <select
                      value={envScope}
                      onChange={(e) => setEnvScope(e.target.value as any)}
                      className="w-full rounded-lg border border-slate-800 bg-slate-950 px-3 py-2 text-slate-200 outline-none focus:border-cyan-500 font-mono"
                    >
                      <option value="production">Production</option>
                      <option value="staging">Staging</option>
                      <option value="development">Development</option>
                      <option value="all">All Environments</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-slate-400 mb-1 font-medium">Path Restriction Pattern</label>
                    <input
                      type="text"
                      value={pathPattern}
                      onChange={(e) => setPathPattern(e.target.value)}
                      placeholder="e.g. core/* or *"
                      className="w-full rounded-lg border border-slate-800 bg-slate-950 px-3 py-2 text-slate-200 outline-none focus:border-cyan-500 font-mono"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-slate-400 mb-1.5 font-medium">Scoped Permissions</label>
                  <div className="grid grid-cols-2 gap-2">
                    {[
                      { id: 'read', label: 'read:secrets', desc: 'Fetch & decrypt secrets within path' },
                      { id: 'write', label: 'write:secrets', desc: 'Create or update secrets' },
                      { id: 'rotate', label: 'rotate:secrets', desc: 'Trigger secret rotation' },
                      { id: 'dynamic_issue', label: 'dynamic:issue', desc: 'Mint ephemeral credentials' }
                    ].map(perm => (
                      <div
                        key={perm.id}
                        onClick={() => togglePolicy(perm.id as any)}
                        className={`p-2.5 rounded-lg border cursor-pointer transition-all ${
                          policies.includes(perm.id as any)
                            ? 'border-cyan-500/60 bg-cyan-950/20'
                            : 'border-slate-800 bg-slate-900/40 hover:border-slate-700'
                        }`}
                      >
                        <div className="font-mono text-xs font-semibold text-slate-200">{perm.label}</div>
                        <div className="text-[10px] text-slate-400 mt-0.5">{perm.desc}</div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-800">
                  <button
                    onClick={closeCreateModal}
                    className="px-3 py-1.5 text-slate-400 hover:text-white"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleCreate}
                    disabled={!tokenName.trim() || policies.length === 0}
                    className="px-4 py-1.5 font-semibold text-slate-900 bg-cyan-400 rounded-lg hover:bg-cyan-300 disabled:opacity-50 transition-colors"
                  >
                    Generate Token
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
