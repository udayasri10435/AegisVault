import React, { useState, useEffect } from 'react';
import { useVault } from '../context/VaultContext';
import { DynamicEngineType, DynamicLease } from '../types/vault';
import { formatCountdown, maskSecret } from '../lib/cryptoUtils';
import { 
  Zap, 
  Clock, 
  RotateCw, 
  ShieldX, 
  Copy, 
  Check, 
  Database, 
  Cloud, 
  Server, 
  Github, 
  Plus, 
  Terminal,
  AlertTriangle,
  CheckCircle2
} from 'lucide-react';

interface DynamicSecretsProps {
  onOpenMintModal: () => void;
}

export const DynamicSecrets: React.FC<DynamicSecretsProps> = ({ onOpenMintModal }) => {
  const { 
    dynamicEngines, 
    dynamicLeases, 
    renewDynamicLease, 
    revokeDynamicLease,
    addToast
  } = useVault();

  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [filterStatus, setFilterStatus] = useState<'all' | 'active' | 'revoked' | 'expired'>('active');
  const [inspectingLease, setInspectingLease] = useState<DynamicLease | null>(null);

  // Force tick for smooth countdown UI updates every 1s
  const [, setTick] = useState(0);
  useEffect(() => {
    const timer = setInterval(() => setTick(t => t + 1), 1000);
    return () => clearInterval(timer);
  }, []);

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    addToast({
      type: 'info',
      title: 'Credentials Copied',
      message: 'Ephemeral secret copied to clipboard.'
    });
    setTimeout(() => setCopiedId(null), 2000);
  };

  const filteredLeases = dynamicLeases.filter(lease => {
    if (filterStatus === 'all') return true;
    return lease.status === filterStatus;
  });

  const getEngineIcon = (engine: DynamicEngineType) => {
    switch (engine) {
      case 'postgresql': return Database;
      case 'aws-sts': return Cloud;
      case 'redis': return Server;
      case 'github': return Github;
      default: return Zap;
    }
  };

  return (
    <div className="space-y-6">
      {/* Overview Cards: Dynamic Engines Backends */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <div>
            <h2 className="text-sm font-semibold text-slate-100 flex items-center gap-2">
              <Zap className="h-4 w-4 text-amber-400" />
              Dynamic Secret Engines
            </h2>
            <p className="text-xs text-slate-400">
              Ephemeral credentials minted on-the-fly with strict lease lifetimes. Zero long-lived credentials in production.
            </p>
          </div>
          <button
            onClick={onOpenMintModal}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-900 bg-amber-400 rounded-lg hover:bg-amber-300 transition-colors cursor-pointer"
          >
            <Plus className="h-3.5 w-3.5 stroke-[2.5]" />
            <span>Mint Ephemeral Lease</span>
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
          {dynamicEngines.map(engine => {
            const Icon = getEngineIcon(engine.id);
            const activeForEngine = dynamicLeases.filter(l => l.engine === engine.id && l.status === 'active').length;

            return (
              <div 
                key={engine.id}
                className="rounded-xl border border-slate-800 bg-slate-900/50 p-4 space-y-3 flex flex-col justify-between hover:border-slate-700 transition-all"
              >
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="p-1.5 rounded-lg bg-amber-500/10 text-amber-400 border border-amber-500/20">
                        <Icon className="h-4 w-4" />
                      </div>
                      <span className="font-semibold text-xs text-slate-200">{engine.name}</span>
                    </div>
                  </div>
                  <p className="text-[11px] text-slate-400 line-clamp-2 leading-relaxed">
                    {engine.description}
                  </p>
                </div>

                <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-[11px]">
                  <span className="text-slate-500 font-mono">
                    TTL: {Math.floor(engine.defaultTtlSeconds / 60)}m
                  </span>
                  <span className="text-amber-400 font-mono font-medium">
                    {activeForEngine} active {activeForEngine === 1 ? 'lease' : 'leases'}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Dynamic Leases Table & Manager */}
      <div className="space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <h3 className="text-xs font-semibold text-slate-200 uppercase tracking-wider font-mono">
              Active Dynamic Leases
            </h3>
            <span className="text-xs text-slate-500">
              ({dynamicLeases.filter(l => l.status === 'active').length} currently valid)
            </span>
          </div>

          {/* Filter tabs */}
          <div className="flex items-center gap-1 bg-slate-900 p-0.5 rounded-lg border border-slate-800 text-xs">
            {(['active', 'all', 'revoked', 'expired'] as const).map(st => (
              <button
                key={st}
                onClick={() => setFilterStatus(st)}
                className={`px-3 py-1 rounded capitalize font-medium transition-all cursor-pointer ${
                  filterStatus === st
                    ? 'bg-slate-800 text-cyan-300 shadow-sm'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {st}
              </button>
            ))}
          </div>
        </div>

        {/* Leases Table */}
        <div className="rounded-xl border border-slate-800/80 bg-slate-900/40 overflow-hidden">
          {filteredLeases.length === 0 ? (
            <div className="py-12 text-center">
              <Zap className="h-6 w-6 text-slate-600 mx-auto mb-2" />
              <div className="text-xs font-semibold text-slate-300">No dynamic leases with status "{filterStatus}"</div>
              <p className="text-[11px] text-slate-500 mt-0.5">
                Generate an ephemeral database role or AWS STS session token to test just-in-time credentials.
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="border-b border-slate-800/80 bg-slate-950/60 text-slate-400 text-[11px] uppercase tracking-wider font-mono">
                    <th className="py-2.5 px-4 font-medium">Lease ID & Engine</th>
                    <th className="py-2.5 px-4 font-medium">Ephemeral User / Target</th>
                    <th className="py-2.5 px-3 font-medium">Privilege Role</th>
                    <th className="py-2.5 px-3 font-medium">TTL Countdown</th>
                    <th className="py-2.5 px-3 font-medium">Status</th>
                    <th className="py-2.5 px-4 text-right font-medium">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 font-sans">
                  {filteredLeases.map(lease => {
                    const countdown = formatCountdown(lease.expiresAt);
                    const Icon = getEngineIcon(lease.engine);
                    const isActive = lease.status === 'active';

                    return (
                      <tr 
                        key={lease.leaseId}
                        className="hover:bg-slate-800/30 transition-colors"
                      >
                        {/* Lease ID & Engine */}
                        <td className="py-3 px-4">
                          <div className="flex items-center gap-2">
                            <div className="p-1 rounded bg-slate-800 text-slate-300">
                              <Icon className="h-3.5 w-3.5 text-amber-400" />
                            </div>
                            <div>
                              <button
                                onClick={() => setInspectingLease(lease)}
                                className="font-mono text-cyan-400 hover:underline cursor-pointer font-semibold text-xs block"
                              >
                                {lease.leaseId}
                              </button>
                              <span className="text-[10px] text-slate-500 font-mono uppercase">
                                {lease.engine}
                              </span>
                            </div>
                          </div>
                        </td>

                        {/* Ephemeral User & Target */}
                        <td className="py-3 px-4">
                          <div className="font-mono text-slate-200 text-xs flex items-center gap-1.5">
                            <span>{lease.username}</span>
                            <button
                              onClick={() => handleCopy(lease.username, `${lease.leaseId}_user`)}
                              className="text-slate-500 hover:text-slate-300 p-0.5"
                              title="Copy username"
                            >
                              {copiedId === `${lease.leaseId}_user` ? <Check className="h-3 w-3 text-emerald-400" /> : <Copy className="h-3 w-3" />}
                            </button>
                          </div>
                          <div className="text-[10px] font-mono text-slate-500 truncate max-w-[200px] mt-0.5">
                            {lease.targetResource}
                          </div>
                        </td>

                        {/* Role */}
                        <td className="py-3 px-3">
                          <span className="font-mono text-xs text-slate-300 bg-slate-800/80 px-2 py-0.5 rounded border border-slate-700/60">
                            {lease.role}
                          </span>
                        </td>

                        {/* TTL Countdown with visual progress bar */}
                        <td className="py-3 px-3 min-w-[140px]">
                          {isActive ? (
                            <div className="space-y-1">
                              <div className="flex items-center justify-between text-[11px] font-mono">
                                <span className={countdown.isPast ? 'text-rose-400' : 'text-amber-400'}>
                                  {countdown.label}
                                </span>
                                <span className="text-slate-500 text-[10px] tabular-nums">
                                  {Math.round(countdown.percent)}%
                                </span>
                              </div>
                              <div className="h-1.5 w-full bg-slate-800 rounded-full overflow-hidden">
                                <div 
                                  className={`h-full transition-all duration-1000 ${
                                    countdown.percent < 25 ? 'bg-rose-500' : countdown.percent < 50 ? 'bg-amber-500' : 'bg-emerald-500'
                                  }`}
                                  style={{ width: `${countdown.percent}%` }}
                                />
                              </div>
                            </div>
                          ) : (
                            <span className="font-mono text-[11px] text-slate-500">
                              Terminated
                            </span>
                          )}
                        </td>

                        {/* Status */}
                        <td className="py-3 px-3">
                          <span className={`text-[11px] font-mono px-2 py-0.5 rounded ${
                            lease.status === 'active' 
                              ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' 
                              : lease.status === 'revoked' 
                                ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20' 
                                : 'bg-slate-800 text-slate-400'
                          }`}>
                            {lease.status.toUpperCase()}
                          </span>
                        </td>

                        {/* Actions */}
                        <td className="py-3 px-4 text-right whitespace-nowrap">
                          {isActive ? (
                            <div className="flex items-center justify-end gap-1.5">
                              {/* Renew */}
                              <button
                                onClick={() => renewDynamicLease(lease.leaseId, 3600)}
                                className="px-2 py-1 text-[11px] font-medium text-slate-300 bg-slate-800 hover:text-cyan-300 hover:bg-slate-700 rounded transition-all cursor-pointer flex items-center gap-1"
                                title="Renew lease for +1 hour"
                              >
                                <RotateCw className="h-3 w-3" />
                                <span>+1h</span>
                              </button>

                              {/* Inspect Credentials */}
                              <button
                                onClick={() => setInspectingLease(lease)}
                                className="px-2 py-1 text-[11px] font-medium text-cyan-300 bg-cyan-950/40 hover:bg-cyan-900/60 border border-cyan-800/40 rounded transition-colors cursor-pointer"
                              >
                                Credentials
                              </button>

                              {/* Immediate Revoke */}
                              <button
                                onClick={() => {
                                  if (confirm(`Immediately revoke lease ${lease.leaseId}? Upstream database/API credentials will be dropped immediately.`)) {
                                    revokeDynamicLease(lease.leaseId);
                                  }
                                }}
                                className="p-1 rounded text-slate-500 hover:text-rose-400 hover:bg-rose-500/10 transition-colors cursor-pointer"
                                title="Revoke immediately"
                              >
                                <ShieldX className="h-3.5 w-3.5" />
                              </button>
                            </div>
                          ) : (
                            <button
                              onClick={() => setInspectingLease(lease)}
                              className="text-xs text-slate-500 hover:text-slate-300"
                            >
                              View Archive
                            </button>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      {/* Inspect Credentials Drawer/Modal */}
      {inspectingLease && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
          <div className="w-full max-w-xl rounded-xl border border-slate-800 bg-[#0F172A] p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <Zap className="h-4 w-4 text-amber-400" />
                  Dynamic Credentials: <span className="font-mono text-amber-300">{inspectingLease.leaseId}</span>
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Ephemeral access bundle. Revokes automatically when lease TTL expires.
                </p>
              </div>
              <button
                onClick={() => setInspectingLease(null)}
                className="text-slate-400 hover:text-white text-xs px-2 py-1 rounded bg-slate-800/80 cursor-pointer"
              >
                Close
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div className="flex items-center justify-between bg-slate-950 p-2.5 rounded-lg border border-slate-800">
                <span className="text-slate-400">Lease Status:</span>
                <span className={`font-mono uppercase font-semibold ${
                  inspectingLease.status === 'active' ? 'text-emerald-400' : 'text-rose-400'
                }`}>
                  {inspectingLease.status}
                </span>
              </div>

              {Object.entries(inspectingLease.credentials).map(([key, val]) => (
                <div key={key} className="space-y-1">
                  <div className="flex items-center justify-between text-slate-400 font-mono text-[11px]">
                    <span>{key}</span>
                    <button
                      onClick={() => handleCopy(val, key)}
                      className="text-cyan-400 hover:underline flex items-center gap-1"
                    >
                      {copiedId === key ? <Check className="h-3 w-3 text-emerald-400" /> : <Copy className="h-3 w-3" />}
                      <span>Copy</span>
                    </button>
                  </div>
                  <div className="bg-slate-950 border border-slate-800 rounded p-2.5 font-mono text-slate-200 text-xs break-all select-all">
                    {val}
                  </div>
                </div>
              ))}
            </div>

            <div className="flex items-center justify-between pt-3 border-t border-slate-800 text-xs">
              <span className="text-slate-500 font-mono">
                Expires: {new Date(inspectingLease.expiresAt).toLocaleString()}
              </span>
              {inspectingLease.status === 'active' && (
                <button
                  onClick={() => {
                    revokeDynamicLease(inspectingLease.leaseId);
                    setInspectingLease(null);
                  }}
                  className="px-3 py-1.5 rounded-md text-xs font-semibold bg-rose-500/20 text-rose-300 hover:bg-rose-500/30 border border-rose-500/40 transition-colors"
                >
                  Revoke Immediately
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
