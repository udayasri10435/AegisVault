import React, { useState } from 'react';
import { useVault } from '../context/VaultContext';
import { 
  Terminal, 
  Code, 
  Copy, 
  Check, 
  Play, 
  CornerDownLeft, 
  Trash2,
  FileCode,
  Layers,
  Server
} from 'lucide-react';

export const DeveloperPlayground: React.FC = () => {
  const { 
    secrets, 
    rotateSecret, 
    issueDynamicCredential, 
    auditLogs, 
    cryptoState, 
    addToast 
  } = useVault();

  // Terminal state
  const [terminalInput, setTerminalInput] = useState('');
  const [terminalOutput, setTerminalOutput] = useState<Array<{ text: string; type: 'cmd' | 'output' | 'error' | 'success' }>>([
    { text: 'AegisVault CLI v2.8.4 initialized.', type: 'output' },
    { text: 'Authenticated as elena.rostova@aegis.corp (Role: SecOps Admin)', type: 'output' },
    { text: 'Type "help" for available commands or click quick actions below.', type: 'output' }
  ]);
  const [activeSdk, setActiveSdk] = useState<'node' | 'python' | 'go' | 'rust' | 'curl' | 'k8s' | 'terraform'>('node');
  const [copiedSdk, setCopiedSdk] = useState(false);

  const executeCommand = async (rawCmd: string) => {
    const cmd = rawCmd.trim();
    if (!cmd) return;

    const newOutputs: Array<{ text: string; type: 'cmd' | 'output' | 'error' | 'success' }> = [
      ...terminalOutput,
      { text: `$ ${cmd}`, type: 'cmd' }
    ];

    const parts = cmd.split(' ');
    const root = parts[0];
    const sub = parts[1];

    if (cmd === 'clear') {
      setTerminalOutput([]);
      setTerminalInput('');
      return;
    }

    if (cmd === 'help') {
      newOutputs.push({
        text: `Available AegisVault CLI Commands:
  aegis run -- <command>           Inject secrets into process environment (zero-disk)
  aegis get <secret_name>          Retrieve and decrypt secret value
  aegis rotate <secret_name>       Trigger on-demand cryptographic rotation
  aegis dynamic <engine> [--ttl]   Mint short-lived ephemeral credentials (postgres/aws/redis)
  aegis audit [--tail <N>]         Inspect cryptographically chained audit blocks
  aegis status                     Display vault seal & AES-256-GCM crypto ring state
  clear                            Clear terminal console`,
        type: 'output'
      });
    } else if (cmd.startsWith('aegis run --')) {
      const targetProc = cmd.replace('aegis run --', '').trim() || 'npm start';
      newOutputs.push({
        text: `[aegis] Fetching secrets for environment [production]...`,
        type: 'output'
      });
      newOutputs.push({
        text: `[aegis] Injected 8 environment variables into PID 48291 (${targetProc}) via protected memory pipe:
  ✓ DATABASE_URL
  ✓ STRIPE_SECRET_KEY
  ✓ JWT_SIGNING_PRIVATE_KEY
  ✓ AWS_SECRET_ACCESS_KEY
  ✓ OPENAI_API_KEY
[aegis] Process spawned: ${targetProc} (Zero secrets written to filesystem)`,
        type: 'success'
      });
    } else if (cmd.startsWith('aegis get')) {
      const target = parts[2] || 'DATABASE_URL';
      const sec = secrets.find(s => s.name.toLowerCase() === target.toLowerCase() || s.id === target);
      if (sec) {
        if (cryptoState.isSealed) {
          newOutputs.push({ text: `[error] Vault is currently sealed. Submit 3 of 5 Shamir shares to unlock.`, type: 'error' });
        } else {
          newOutputs.push({
            text: `[aegis] Secret: ${sec.name} (v${sec.currentVersion})
Path: ${sec.path}
Environment: ${sec.environment}
Value: ${sec.versions[0]?.value}
Checksum: ${sec.versions[0]?.checksum}`,
            type: 'output'
          });
        }
      } else {
        newOutputs.push({ text: `[error] Secret "${target}" not found in current environment.`, type: 'error' });
      }
    } else if (cmd.startsWith('aegis dynamic')) {
      const engine = parts[2] || 'postgres';
      const mapped = engine === 'postgres' ? 'postgresql' : engine === 'aws' ? 'aws-sts' : engine;
      try {
        const lease = issueDynamicCredential(mapped, 'app_runner', 3600);
        newOutputs.push({
          text: `[aegis] Dynamic Lease Minted: ${lease.leaseId}
Engine: ${lease.engine}
Ephemeral Username: ${lease.username}
Lease Expiration: ${new Date(lease.expiresAt).toLocaleTimeString()} (TTL: 3600s)
Credentials: ${JSON.stringify(lease.credentials, null, 2)}`,
          type: 'success'
        });
      } catch (e) {
        newOutputs.push({ text: `[error] Failed to mint dynamic lease for ${engine}.`, type: 'error' });
      }
    } else if (cmd.startsWith('aegis rotate')) {
      const target = parts[2] || 'DATABASE_URL';
      const sec = secrets.find(s => s.name.toLowerCase() === target.toLowerCase() || s.id === target);
      if (sec) {
        await rotateSecret(sec.id, 'CLI manual trigger');
        newOutputs.push({
          text: `[aegis] Secret ${sec.name} rotated to v${sec.currentVersion + 1}. Upstream services notified.`,
          type: 'success'
        });
      } else {
        newOutputs.push({ text: `[error] Secret "${target}" not found.`, type: 'error' });
      }
    } else if (cmd.startsWith('aegis audit')) {
      const logs = auditLogs.slice(0, 3);
      const text = logs.map(l => `[${l.timestamp.slice(11, 19)}] ${l.action} -> ${l.resource} (Actor: ${l.actor.email}) Hash: ${l.tamperHash.slice(0, 8)}...`).join('\n');
      newOutputs.push({
        text: `Latest Verified Audit Blocks:\n${text}`,
        type: 'output'
      });
    } else if (cmd.startsWith('aegis status')) {
      newOutputs.push({
        text: `Vault Cryptographic State:
  Status: ${cryptoState.isSealed ? 'SEALED (Locked)' : 'UNSEALED (Operational)'}
  Envelope Cipher: ${cryptoState.algorithm}
  Key Epoch: ${cryptoState.keyEpoch}
  Shamir Threshold: ${cryptoState.shamirThreshold} of ${cryptoState.shamirTotalShares} shares required`,
        type: 'output'
      });
    } else {
      newOutputs.push({
        text: `Unknown command: "${cmd}". Type "help" for a list of available commands.`,
        type: 'error'
      });
    }

    setTerminalOutput(newOutputs);
    setTerminalInput('');
  };

  const sdkSnippets: Record<string, { lang: string; code: string }> = {
    node: {
      lang: 'typescript',
      code: `import { AegisClient } from '@aegisvault/sdk';

// Initialize with environment service token
const aegis = new AegisClient({
  token: process.env.AEGIS_SERVICE_TOKEN,
  environment: 'production'
});

async function main() {
  // 1. Fetch encrypted secret with auto-caching
  const dbUrl = await aegis.getSecret('core/database/primary');
  console.log('Database connected:', dbUrl.masked);

  // 2. Request short-lived dynamic PostgreSQL credentials (TTL: 1h)
  const lease = await aegis.dynamic.issue('postgresql', {
    role: 'read_only_analyst',
    ttl: '1h'
  });
  console.log('Ephemeral User:', lease.username);
  console.log('Connection String:', lease.credentials.connectionString);

  // 3. Listen for automated rotation events
  aegis.onRotation('core/database/primary', (newVersion) => {
    console.log('Pool recycling to new credential version:', newVersion.version);
  });
}

main();`
    },
    python: {
      lang: 'python',
      code: `import os
from aegisvault import AegisClient

client = AegisClient(
    token=os.environ.get("AEGIS_SERVICE_TOKEN"),
    environment="production"
)

# Fetch decrypted secret value
db_url = client.get_secret("core/database/primary")

# Mint dynamic AWS STS credentials for short-lived task
sts_lease = client.dynamic.issue(
    engine="aws-sts",
    role="s3_read_archive",
    ttl_seconds=3600
)

print(f"Issued Temp AWS Key: {sts_lease.credentials['AccessKeyId']}")`
    },
    go: {
      lang: 'go',
      code: `package main

import (
	"context"
	"fmt"
	"os"

	"github.com/aegisvault/aegis-go"
)

func main() {
	ctx := context.Background()
	client, err := aegis.NewClient(&aegis.Config{
		Token:       os.Getenv("AEGIS_SERVICE_TOKEN"),
		Environment: "production",
	})
	if err != nil {
		panic(err)
	}

	secret, err := client.GetSecret(ctx, "billing/stripe/live")
	if err != nil {
		panic(err)
	}

	fmt.Printf("Secret %s loaded (v%d)\\n", secret.Name, secret.Version)
}`
    },
    rust: {
      lang: 'rust',
      code: `use aegis_sdk::Client;

#[tokio::main]
async fn main() -> Result<(), Box<dyn std.error::Error>> {
    let client = Client::builder()
        .with_token(std::env::var("AEGIS_SERVICE_TOKEN")?)
        .with_environment("production")
        .build()?;

    let db_url = client.get_secret("core/database/primary").await?;
    println!("Retrieved secret: v{}", db_url.version());

    Ok(())
}`
    },
    curl: {
      lang: 'bash',
      code: `# 1. Fetch secret via REST API
curl -X GET "https://api.aegisvault.io/v1/secrets/core/database/primary" \\
  -H "Authorization: Bearer aeg_live_tok_9f82a1b2c3d4..." \\
  -H "X-Aegis-Environment: production"

# 2. Mint dynamic ephemeral PostgreSQL credentials
curl -X POST "https://api.aegisvault.io/v1/dynamic/postgresql/issue" \\
  -H "Authorization: Bearer aeg_live_tok_9f82a1b2c3d4..." \\
  -H "Content-Type: application/json" \\
  -d '{"role": "read_write_app", "ttl_seconds": 3600}'`
    },
    k8s: {
      lang: 'yaml',
      code: `apiVersion: external-secrets.io/v1beta1
kind: SecretStore
metadata:
  name: aegis-backend-store
  namespace: production
spec:
  provider:
    generic:
      server: "https://api.aegisvault.io"
      auth:
        secretRef:
          token: "aeg_live_tok_k8s_4c11..."
---
apiVersion: external-secrets.io/v1beta1
kind: ExternalSecret
metadata:
  name: core-app-secrets
  namespace: production
spec:
  refreshInterval: 1h
  secretStoreRef:
    name: aegis-backend-store
    kind: SecretStore
  target:
    name: core-app-k8s-secret
  data:
    - secretKey: DATABASE_URL
      remoteRef:
        key: core/database/primary`
    },
    terraform: {
      lang: 'hcl',
      code: `terraform {
  required_providers {
    aegis = {
      source  = "aegisvault/aegis"
      version = "~> 2.8"
    }
  }
}

provider "aegis" {
  token       = var.aegis_service_token
  environment = "production"
}

# Fetch secret for ECS Task Definition
data "aegis_secret" "database" {
  path = "core/database/primary"
}

# Provision dynamic PostgreSQL role for migration job
resource "aegis_dynamic_credential" "migration_runner" {
  engine      = "postgresql"
  role        = "ddl_migration_runner"
  ttl_seconds = 7200
}`
    }
  };

  const handleCopyCode = () => {
    navigator.clipboard.writeText(sdkSnippets[activeSdk].code);
    setCopiedSdk(true);
    addToast({
      type: 'info',
      title: 'Code Copied',
      message: 'Integration snippet copied to clipboard.'
    });
    setTimeout(() => setCopiedSdk(false), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Interactive CLI Terminal Section */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-sm font-semibold text-slate-100 flex items-center gap-2">
              <Terminal className="h-4 w-4 text-cyan-400" />
              Interactive Aegis CLI Emulator
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Experience zero-disk secret injection, dynamic lease generation, and audit verification.
            </p>
          </div>
          <button
            onClick={() => setTerminalOutput([])}
            className="text-xs text-slate-400 hover:text-slate-200 flex items-center gap-1 cursor-pointer"
          >
            <Trash2 className="h-3 w-3" />
            <span>Clear Terminal</span>
          </button>
        </div>

        {/* Quick action command chips */}
        <div className="flex flex-wrap items-center gap-1.5 text-xs">
          <span className="text-slate-500 font-mono text-[11px]">Quick Run:</span>
          {[
            'aegis run -- npm start',
            'aegis get DATABASE_URL',
            'aegis dynamic postgres',
            'aegis rotate DATABASE_URL',
            'aegis audit',
            'aegis status'
          ].map(quickCmd => (
            <button
              key={quickCmd}
              onClick={() => executeCommand(quickCmd)}
              className="px-2.5 py-1 rounded bg-slate-900 hover:bg-slate-800 border border-slate-800 hover:border-cyan-500/40 text-slate-300 font-mono text-[11px] transition-all cursor-pointer"
            >
              {quickCmd}
            </button>
          ))}
        </div>

        {/* Terminal Window */}
        <div className="rounded-xl border border-slate-800 bg-[#060911] shadow-2xl overflow-hidden font-mono text-xs">
          {/* Terminal Title Bar */}
          <div className="flex items-center justify-between px-4 py-2 border-b border-slate-800/80 bg-slate-950/70">
            <div className="flex items-center gap-2">
              <div className="h-2.5 w-2.5 rounded-full bg-rose-500/80" />
              <div className="h-2.5 w-2.5 rounded-full bg-amber-500/80" />
              <div className="h-2.5 w-2.5 rounded-full bg-emerald-500/80" />
              <span className="text-[11px] text-slate-400 ml-2">aegis-cli — session #4829</span>
            </div>
            <span className="text-[10px] text-slate-600">bash / zsh</span>
          </div>

          {/* Terminal Logs */}
          <div className="p-4 space-y-2 max-h-72 overflow-y-auto no-scrollbar">
            {terminalOutput.map((item, idx) => (
              <div 
                key={idx} 
                className={`whitespace-pre-wrap leading-relaxed ${
                  item.type === 'cmd' 
                    ? 'text-cyan-400 font-bold' 
                    : item.type === 'success' 
                      ? 'text-emerald-400' 
                      : item.type === 'error' 
                        ? 'text-rose-400' 
                        : 'text-slate-300'
                }`}
              >
                {item.text}
              </div>
            ))}
          </div>

          {/* Terminal Input Row */}
          <form 
            onSubmit={(e) => {
              e.preventDefault();
              executeCommand(terminalInput);
            }}
            className="flex items-center gap-2 px-4 py-3 border-t border-slate-800/80 bg-slate-950/40"
          >
            <span className="text-cyan-400 font-bold">$</span>
            <input
              type="text"
              value={terminalInput}
              onChange={(e) => setTerminalInput(e.target.value)}
              placeholder="type 'help' or any command..."
              className="flex-1 bg-transparent border-none outline-none text-slate-200 placeholder:text-slate-600 font-mono text-xs"
            />
            <button
              type="submit"
              className="text-slate-500 hover:text-cyan-400 transition-colors cursor-pointer"
            >
              <CornerDownLeft className="h-3.5 w-3.5" />
            </button>
          </form>
        </div>
      </div>

      {/* Multi-Language SDK Snippets */}
      <div className="space-y-3 pt-2">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-sm font-semibold text-slate-100 flex items-center gap-2">
              <Code className="h-4 w-4 text-cyan-400" />
              SDKs & Infrastructure as Code Integration
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Production-tested libraries with automatic secret caching, background rotation listeners, and lease management.
            </p>
          </div>

          <button
            onClick={handleCopyCode}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-300 bg-slate-800 hover:text-white border border-slate-700 rounded-lg transition-colors cursor-pointer"
          >
            {copiedSdk ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5 text-slate-400" />}
            <span>Copy Snippet</span>
          </button>
        </div>

        {/* SDK Language Tabs */}
        <div className="flex items-center gap-1.5 border-b border-slate-800 pb-2 overflow-x-auto no-scrollbar">
          {[
            { id: 'node', label: 'Node.js / TS' },
            { id: 'python', label: 'Python' },
            { id: 'go', label: 'Go' },
            { id: 'rust', label: 'Rust' },
            { id: 'curl', label: 'cURL / REST' },
            { id: 'k8s', label: 'Kubernetes (ESO)' },
            { id: 'terraform', label: 'Terraform' }
          ].map(sdk => (
            <button
              key={sdk.id}
              onClick={() => setActiveSdk(sdk.id as any)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all cursor-pointer whitespace-nowrap ${
                activeSdk === sdk.id
                  ? 'bg-cyan-500/10 text-cyan-300 border border-cyan-500/30'
                  : 'text-slate-400 hover:text-white hover:bg-slate-900'
              }`}
            >
              {sdk.label}
            </button>
          ))}
        </div>

        {/* Code Snippet Box */}
        <div className="rounded-xl border border-slate-800 bg-[#090D16] p-4 overflow-x-auto">
          <pre className="font-mono text-xs text-slate-300 leading-relaxed">
            <code>{sdkSnippets[activeSdk].code}</code>
          </pre>
        </div>
      </div>
    </div>
  );
};
