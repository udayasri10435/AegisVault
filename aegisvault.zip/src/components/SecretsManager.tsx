import React, { useState } from 'react';
import { useVault } from '../context/VaultContext';
import { Secret, SecretVersion, Environment } from '../types/vault';
import { maskSecret, formatRelativeTime, formatCountdown } from '../lib/cryptoUtils';
import { 
  Key, 
  Eye, 
  EyeOff, 
  Copy, 
  Check, 
  RotateCw, 
  History, 
  Trash2, 
  Edit3, 
  Upload, 
  Download, 
  Folder, 
  ShieldAlert, 
  Calendar,
  AlertCircle,
  FileCode,
  Tag
} from 'lucide-react';

interface SecretsManagerProps {
  onOpenNewSecretModal: () => void;
  onOpenShamirModal: () => void;
}

export const SecretsManager: React.FC<SecretsManagerProps> = ({ 
  onOpenNewSecretModal,
  onOpenShamirModal
}) => {
  const { 
    filteredSecrets, 
    unmaskedSecretIds, 
    toggleMaskSecret, 
    rotateSecret, 
    rollbackSecretVersion,
    deleteSecret,
    updateSecretValue,
    cryptoState,
    addToast,
    importSecretsFromEnv,
    selectedEnv
  } = useVault();

  // State for modals
  const [copiedSecretId, setCopiedSecretId] = useState<string | null>(null);
  const [inspectingSecret, setInspectingSecret] = useState<Secret | null>(null);
  const [editingSecret, setEditingSecret] = useState<Secret | null>(null);
  const [editValue, setEditValue] = useState('');
  const [editReason, setEditReason] = useState('');
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const [importEnvContent, setImportEnvContent] = useState('');
  const [importTargetEnv, setImportTargetEnv] = useState<Environment>('production');
  const [isExportModalOpen, setIsExportModalOpen] = useState(false);
  const [exportFormat, setExportFormat] = useState<'env' | 'k8s' | 'json' | 'docker'>('env');
  const [rotatingSecretId, setRotatingSecretId] = useState<string | null>(null);

  const handleCopy = (secret: Secret) => {
    if (cryptoState.isSealed) {
      addToast({
        type: 'error',
        title: 'Vault Sealed',
        message: 'Secrets cannot be copied while vault is sealed.'
      });
      return;
    }
    const currentVal = secret.versions[0]?.value || '';
    navigator.clipboard.writeText(currentVal);
    setCopiedSecretId(secret.id);
    addToast({
      type: 'info',
      title: 'Secret Copied',
      message: `${secret.name} copied to clipboard.`
    });
    setTimeout(() => setCopiedSecretId(null), 2000);
  };

  const handleRotate = async (secret: Secret) => {
    if (cryptoState.isSealed) {
      onOpenShamirModal();
      return;
    }
    setRotatingSecretId(secret.id);
    try {
      await rotateSecret(secret.id);
    } finally {
      setRotatingSecretId(null);
    }
  };

  const openEditModal = (secret: Secret) => {
    setEditingSecret(secret);
    setEditValue(secret.versions[0]?.value || '');
    setEditReason('');
  };

  const handleSaveEdit = () => {
    if (!editingSecret || !editValue.trim()) return;
    updateSecretValue(editingSecret.id, editValue.trim(), editReason || 'Manual update');
    setEditingSecret(null);
  };

  // Generate export formats
  const generateExportContent = () => {
    const list = filteredSecrets;
    if (exportFormat === 'env') {
      return list.map(s => `# ${s.description}\n${s.name}="${s.versions[0]?.value || ''}"`).join('\n\n');
    }
    if (exportFormat === 'json') {
      const obj: Record<string, string> = {};
      list.forEach(s => {
        obj[s.name] = s.versions[0]?.value || '';
      });
      return JSON.stringify(obj, null, 2);
    }
    if (exportFormat === 'docker') {
      const envLines = list.map(s => `      - ${s.name}=${s.versions[0]?.value || ''}`).join('\n');
      return `version: '3.8'\nservices:\n  app:\n    image: my-app:latest\n    environment:\n${envLines}`;
    }
    if (exportFormat === 'k8s') {
      const dataLines = list.map(s => `  ${s.name}: ${btoa(s.versions[0]?.value || '')}`).join('\n');
      return `apiVersion: v1\nkind: Secret\nmetadata:\n  name: aegis-synced-secrets\n  namespace: default\ntype: Opaque\ndata:\n${dataLines}`;
    }
    return '';
  };

  const handleDownloadExport = () => {
    const content = generateExportContent();
    const extensions: Record<string, string> = { env: '.env', json: '.json', docker: 'docker-compose.yml', k8s: 'secret.yaml' };
    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `aegis-export-${selectedEnv}${extensions[exportFormat]}`;
    a.click();
    URL.revokeObjectURL(url);
    setIsExportModalOpen(false);
    addToast({
      type: 'success',
      title: 'Export Downloaded',
      message: `Exported ${filteredSecrets.length} secrets in ${exportFormat.toUpperCase()} format.`
    });
  };

  return (
    <div className="space-y-4">
      {/* Top Banner if Vault is Sealed */}
      {cryptoState.isSealed && (
        <div className="rounded-lg border border-rose-500/40 bg-rose-950/30 p-4 text-rose-200 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <ShieldAlert className="h-5 w-5 text-rose-400 shrink-0" />
            <div>
              <div className="text-xs font-semibold uppercase tracking-wider text-rose-300">Vault Sealed</div>
              <div className="text-xs text-rose-400/90 mt-0.5">
                All cryptographic keys are purged from volatile memory. Secrets cannot be unmasked or rotated until 3 of 5 Shamir shares are verified.
              </div>
            </div>
          </div>
          <button
            onClick={onOpenShamirModal}
            className="px-3 py-1.5 rounded-md text-xs font-semibold bg-rose-500 text-white hover:bg-rose-600 transition-colors shrink-0 cursor-pointer"
          >
            Submit Key Shares
          </button>
        </div>
      )}

      {/* Control bar: Summary count + Bulk Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-1">
        <div className="flex items-center gap-2 text-xs text-slate-400">
          <span className="font-semibold text-slate-200">{filteredSecrets.length}</span>
          <span>secrets managed</span>
          <span aria-hidden="true">·</span>
          <span>Env: <strong className="text-cyan-400 font-mono capitalize">{selectedEnv}</strong></span>
          <span aria-hidden="true">·</span>
          <span>Zero-Knowledge AES-256-GCM Envelope</span>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsImportModalOpen(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-300 bg-slate-900 border border-slate-800 rounded-lg hover:border-slate-700 hover:text-white transition-all cursor-pointer"
          >
            <Upload className="h-3.5 w-3.5 text-slate-400" />
            <span>Import .env</span>
          </button>

          <button
            onClick={() => setIsExportModalOpen(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-300 bg-slate-900 border border-slate-800 rounded-lg hover:border-slate-700 hover:text-white transition-all cursor-pointer"
          >
            <Download className="h-3.5 w-3.5 text-slate-400" />
            <span>Export</span>
          </button>

          <button
            onClick={onOpenNewSecretModal}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-900 bg-cyan-400 rounded-lg hover:bg-cyan-300 transition-all cursor-pointer"
          >
            <Key className="h-3.5 w-3.5" />
            <span>Add Secret</span>
          </button>
        </div>
      </div>

      {/* Secrets High-Density Grid */}
      <div className="rounded-xl border border-slate-800/80 bg-slate-900/40 overflow-hidden">
        {filteredSecrets.length === 0 ? (
          <div className="py-16 text-center">
            <Key className="h-8 w-8 text-slate-600 mx-auto mb-3" />
            <div className="text-sm font-semibold text-slate-300">No secrets found</div>
            <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
              There are no secrets matching your current environment or search criteria.
            </p>
            <button
              onClick={onOpenNewSecretModal}
              className="mt-4 px-3.5 py-1.5 text-xs font-medium text-slate-900 bg-cyan-400 rounded-lg hover:bg-cyan-300 transition-colors"
            >
              Provision First Secret
            </button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-800/80 bg-slate-950/60 text-slate-400 text-[11px] uppercase tracking-wider font-mono">
                  <th className="py-2.5 px-4 font-medium">Path & Name</th>
                  <th className="py-2.5 px-4 font-medium">Value (AES-256)</th>
                  <th className="py-2.5 px-3 font-medium">Ver</th>
                  <th className="py-2.5 px-3 font-medium">Rotation Schedule</th>
                  <th className="py-2.5 px-3 font-medium">Last Modified</th>
                  <th className="py-2.5 px-4 text-right font-medium">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-sans">
                {filteredSecrets.map(secret => {
                  const isUnmasked = !cryptoState.isSealed && !!unmaskedSecretIds[secret.id];
                  const currentVal = secret.versions[0]?.value || '';
                  const isOverdue = secret.rotationPolicy.healthStatus === 'overdue';
                  const isDue = secret.rotationPolicy.healthStatus === 'due';
                  const countdown = formatCountdown(secret.rotationPolicy.nextRotationAt);

                  return (
                    <tr 
                      key={secret.id}
                      className="hover:bg-slate-800/30 transition-colors group"
                    >
                      {/* Name & Path */}
                      <td className="py-3 px-4">
                        <div className="flex flex-col">
                          <div className="flex items-center gap-1.5">
                            <span className="font-mono font-semibold text-slate-100 text-xs tracking-tight">
                              {secret.name}
                            </span>
                            <span className="text-[10px] font-mono text-slate-500 uppercase">
                              [{secret.environment.slice(0, 4)}]
                            </span>
                          </div>
                          <div className="flex items-center gap-1.5 text-[11px] text-slate-500 mt-0.5">
                            <Folder className="h-3 w-3 text-slate-600" />
                            <span className="font-mono text-slate-400">{secret.path}</span>
                            {secret.tags.length > 0 && (
                              <>
                                <span aria-hidden="true">·</span>
                                <span className="text-slate-500">{secret.tags.slice(0, 2).join(', ')}</span>
                              </>
                            )}
                          </div>
                        </div>
                      </td>

                      {/* Secret Value */}
                      <td className="py-3 px-4 min-w-[220px] max-w-[340px]">
                        <div className="flex items-center gap-2">
                          <div className="flex-1 font-mono text-xs truncate bg-slate-950/70 border border-slate-800/80 rounded px-2 py-1 text-slate-300">
                            {cryptoState.isSealed ? (
                              <span className="text-slate-600 select-none">•••••••••••••••• (sealed)</span>
                            ) : isUnmasked ? (
                              <span className="text-emerald-400 select-all">{currentVal}</span>
                            ) : (
                              <span className="text-slate-400 select-none">{maskSecret(currentVal)}</span>
                            )}
                          </div>

                          {/* Reveal/Mask toggle */}
                          <button
                            onClick={() => {
                              if (cryptoState.isSealed) {
                                onOpenShamirModal();
                                return;
                              }
                              toggleMaskSecret(secret.id);
                            }}
                            className="p-1 rounded text-slate-400 hover:text-cyan-400 hover:bg-slate-800 transition-colors cursor-pointer"
                            title={isUnmasked ? "Mask secret" : "Reveal for 15s session"}
                          >
                            {isUnmasked ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
                          </button>

                          {/* Copy button */}
                          <button
                            onClick={() => handleCopy(secret)}
                            className="p-1 rounded text-slate-400 hover:text-cyan-400 hover:bg-slate-800 transition-colors cursor-pointer"
                            title="Copy secret to clipboard"
                          >
                            {copiedSecretId === secret.id ? (
                              <Check className="h-3.5 w-3.5 text-emerald-400" />
                            ) : (
                              <Copy className="h-3.5 w-3.5" />
                            )}
                          </button>
                        </div>
                      </td>

                      {/* Version */}
                      <td className="py-3 px-3">
                        <button
                          onClick={() => setInspectingSecret(secret)}
                          className="font-mono text-xs text-cyan-400 hover:text-cyan-300 hover:underline cursor-pointer flex items-center gap-1"
                          title="View version history & rollback"
                        >
                          <span>v{secret.currentVersion}</span>
                          <History className="h-3 w-3 text-slate-500" />
                        </button>
                      </td>

                      {/* Rotation Schedule */}
                      <td className="py-3 px-3">
                        <div className="flex flex-col text-xs">
                          {secret.rotationPolicy.enabled ? (
                            <>
                              <div className="flex items-center gap-1.5 font-medium">
                                <span className={`text-[11px] ${
                                  isOverdue 
                                    ? 'text-rose-400' 
                                    : isDue 
                                      ? 'text-amber-400' 
                                      : 'text-slate-300'
                                }`}>
                                  {isOverdue ? 'Overdue' : countdown.label}
                                </span>
                                <span className="text-[10px] text-slate-500 font-mono">
                                  ({secret.rotationPolicy.intervalDays}d)
                                </span>
                              </div>
                              <span className="text-[10px] text-slate-500 capitalize">
                                {secret.rotationPolicy.strategy.replace('-', ' ')}
                              </span>
                            </>
                          ) : (
                            <span className="text-slate-600 text-xs">Manual only</span>
                          )}
                        </div>
                      </td>

                      {/* Last Modified */}
                      <td className="py-3 px-3 text-slate-400 text-xs whitespace-nowrap">
                        <div className="tabular-nums font-mono text-[11px]">
                          {formatRelativeTime(secret.updatedAt)}
                        </div>
                        <div className="text-[10px] text-slate-500 truncate max-w-[110px]">
                          {secret.versions[0]?.author.split('@')[0] || 'admin'}
                        </div>
                      </td>

                      {/* Actions */}
                      <td className="py-3 px-4 text-right whitespace-nowrap">
                        <div className="flex items-center justify-end gap-1.5">
                          {/* Quick Rotate Button */}
                          <button
                            onClick={() => handleRotate(secret)}
                            disabled={rotatingSecretId === secret.id}
                            className={`p-1.5 rounded text-slate-400 hover:text-cyan-300 hover:bg-slate-800 transition-all cursor-pointer ${
                              rotatingSecretId === secret.id ? 'animate-spin text-cyan-400' : ''
                            }`}
                            title="Rotate secret value now"
                          >
                            <RotateCw className="h-3.5 w-3.5" />
                          </button>

                          {/* Edit Value */}
                          <button
                            onClick={() => openEditModal(secret)}
                            className="p-1.5 rounded text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition-colors cursor-pointer"
                            title="Edit secret value"
                          >
                            <Edit3 className="h-3.5 w-3.5" />
                          </button>

                          {/* Delete Secret */}
                          <button
                            onClick={() => {
                              if (confirm(`Permanently delete secret "${secret.name}"? This cannot be undone.`)) {
                                deleteSecret(secret.id);
                              }
                            }}
                            className="p-1.5 rounded text-slate-500 hover:text-rose-400 hover:bg-rose-500/10 transition-colors cursor-pointer"
                            title="Delete secret"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Secret Version History & Rollback Modal */}
      {inspectingSecret && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
          <div className="w-full max-w-2xl rounded-xl border border-slate-800 bg-[#0F172A] p-6 shadow-2xl space-y-4 max-h-[85vh] flex flex-col">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <History className="h-4 w-4 text-cyan-400" />
                  Version History: <span className="font-mono text-cyan-300">{inspectingSecret.name}</span>
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Immutable cryptographic ledger of revisions. Rollback mints a new active version.
                </p>
              </div>
              <button
                onClick={() => setInspectingSecret(null)}
                className="text-slate-400 hover:text-white text-xs px-2 py-1 rounded bg-slate-800/80 cursor-pointer"
              >
                Close
              </button>
            </div>

            <div className="overflow-y-auto space-y-3 flex-1 pr-1">
              {inspectingSecret.versions.map((ver, idx) => {
                const isCurrent = ver.version === inspectingSecret.currentVersion;
                return (
                  <div
                    key={ver.version}
                    className={`rounded-lg border p-3.5 space-y-2 transition-all ${
                      isCurrent
                        ? 'border-cyan-500/40 bg-cyan-950/20'
                        : 'border-slate-800 bg-slate-900/40 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between text-xs">
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold text-slate-200">
                          v{ver.version}
                        </span>
                        {isCurrent && (
                          <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                            CURRENT ACTIVE
                          </span>
                        )}
                        <span className="text-slate-500 font-mono text-[11px]">{ver.createdAt}</span>
                      </div>

                      {!isCurrent && (
                        <button
                          onClick={() => {
                            rollbackSecretVersion(inspectingSecret.id, ver.version);
                            setInspectingSecret(null);
                          }}
                          className="px-2 py-1 text-[11px] font-semibold text-cyan-300 bg-slate-800 hover:bg-cyan-500/20 border border-slate-700 rounded transition-colors cursor-pointer"
                        >
                          Rollback to v{ver.version}
                        </button>
                      )}
                    </div>

                    <div className="text-xs text-slate-300 bg-slate-950 p-2 rounded border border-slate-800/80 font-mono break-all">
                      {cryptoState.isSealed ? '•••••••••••• (sealed)' : ver.value}
                    </div>

                    <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1">
                      <span>Reason: <strong className="text-slate-300 font-normal">{ver.changeReason}</strong></span>
                      <span className="font-mono text-slate-500">{ver.checksum}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* Edit Secret Modal */}
      {editingSecret && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
          <div className="w-full max-w-lg rounded-xl border border-slate-800 bg-[#0F172A] p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Edit3 className="h-4 w-4 text-cyan-400" />
                Update Secret: <span className="font-mono text-cyan-300">{editingSecret.name}</span>
              </h3>
              <button
                onClick={() => setEditingSecret(null)}
                className="text-slate-400 hover:text-white text-xs px-2 py-1 rounded bg-slate-800/80 cursor-pointer"
              >
                Cancel
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-400 mb-1 font-medium">New Secret Value</label>
                <textarea
                  rows={4}
                  value={editValue}
                  onChange={(e) => setEditValue(e.target.value)}
                  className="w-full rounded-lg border border-slate-800 bg-slate-950 px-3 py-2 font-mono text-slate-200 outline-none focus:border-cyan-500"
                  placeholder="Enter updated secret payload..."
                />
              </div>

              <div>
                <label className="block text-slate-400 mb-1 font-medium">Change Reason (for audit log & version diff)</label>
                <input
                  type="text"
                  value={editReason}
                  onChange={(e) => setEditReason(e.target.value)}
                  className="w-full rounded-lg border border-slate-800 bg-slate-950 px-3 py-2 text-slate-200 outline-none focus:border-cyan-500"
                  placeholder="e.g. Upgraded API throughput tier / scheduled maintenance"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
              <button
                onClick={() => setEditingSecret(null)}
                className="px-3 py-1.5 text-xs text-slate-400 hover:text-white"
              >
                Cancel
              </button>
              <button
                onClick={handleSaveEdit}
                className="px-4 py-1.5 text-xs font-semibold text-slate-900 bg-cyan-400 rounded-lg hover:bg-cyan-300 transition-colors"
              >
                Save as v{editingSecret.currentVersion + 1}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Bulk Import Modal */}
      {isImportModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
          <div className="w-full max-w-xl rounded-xl border border-slate-800 bg-[#0F172A] p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Upload className="h-4 w-4 text-cyan-400" />
                Bulk Import Secrets from .env
              </h3>
              <button
                onClick={() => setIsImportModalOpen(false)}
                className="text-slate-400 hover:text-white text-xs px-2 py-1 rounded bg-slate-800/80 cursor-pointer"
              >
                Cancel
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div className="flex items-center justify-between">
                <label className="text-slate-400 font-medium">Target Environment</label>
                <div className="flex gap-1">
                  {(['production', 'staging', 'development'] as Environment[]).map(env => (
                    <button
                      key={env}
                      onClick={() => setImportTargetEnv(env)}
                      className={`px-2.5 py-1 rounded capitalize text-xs ${
                        importTargetEnv === env 
                          ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40' 
                          : 'bg-slate-800 text-slate-400 hover:text-white'
                      }`}
                    >
                      {env}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-slate-400 mb-1 font-medium">Paste .env file contents</label>
                <textarea
                  rows={8}
                  value={importEnvContent}
                  onChange={(e) => setImportEnvContent(e.target.value)}
                  className="w-full rounded-lg border border-slate-800 bg-slate-950 p-3 font-mono text-slate-200 outline-none focus:border-cyan-500 text-xs"
                  placeholder={`API_KEY="sk_live_12345"\nDATABASE_URL="postgres://..."\nSTRIPE_KEY="pk_live_..."`}
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
              <button
                onClick={() => setIsImportModalOpen(false)}
                className="px-3 py-1.5 text-xs text-slate-400 hover:text-white"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  const count = importSecretsFromEnv(importEnvContent, importTargetEnv);
                  if (count > 0) {
                    setIsImportModalOpen(false);
                    setImportEnvContent('');
                  }
                }}
                disabled={!importEnvContent.trim()}
                className="px-4 py-1.5 text-xs font-semibold text-slate-900 bg-cyan-400 rounded-lg hover:bg-cyan-300 disabled:opacity-50 transition-colors"
              >
                Import Secrets
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Export Modal */}
      {isExportModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
          <div className="w-full max-w-xl rounded-xl border border-slate-800 bg-[#0F172A] p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Download className="h-4 w-4 text-cyan-400" />
                Export Vault Secrets ({selectedEnv})
              </h3>
              <button
                onClick={() => setIsExportModalOpen(false)}
                className="text-slate-400 hover:text-white text-xs px-2 py-1 rounded bg-slate-800/80 cursor-pointer"
              >
                Cancel
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div className="flex gap-2">
                {[
                  { id: 'env', label: '.env file' },
                  { id: 'json', label: 'JSON Key-Value' },
                  { id: 'k8s', label: 'Kubernetes Secret' },
                  { id: 'docker', label: 'Docker Compose' }
                ].map(fmt => (
                  <button
                    key={fmt.id}
                    onClick={() => setExportFormat(fmt.id as any)}
                    className={`px-3 py-1.5 rounded-lg border text-xs font-medium transition-all ${
                      exportFormat === fmt.id
                        ? 'border-cyan-500 bg-cyan-500/10 text-cyan-300'
                        : 'border-slate-800 bg-slate-900 text-slate-400 hover:text-white'
                    }`}
                  >
                    {fmt.label}
                  </button>
                ))}
              </div>

              <div className="relative">
                <textarea
                  readOnly
                  rows={8}
                  value={generateExportContent()}
                  className="w-full rounded-lg border border-slate-800 bg-slate-950 p-3 font-mono text-slate-300 text-xs outline-none"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
              <button
                onClick={() => setIsExportModalOpen(false)}
                className="px-3 py-1.5 text-xs text-slate-400 hover:text-white"
              >
                Close
              </button>
              <button
                onClick={handleDownloadExport}
                className="px-4 py-1.5 text-xs font-semibold text-slate-900 bg-cyan-400 rounded-lg hover:bg-cyan-300 transition-colors"
              >
                Download File
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
