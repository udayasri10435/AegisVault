import React, { useState } from 'react';
import { useVault } from '../context/VaultContext';
import { DEFAULT_SHAMIR_SHARES } from '../lib/cryptoUtils';
import { 
  ShieldAlert, 
  ShieldCheck, 
  Key, 
  Check, 
  X, 
  Unlock, 
  AlertCircle 
} from 'lucide-react';

interface ShamirUnsealModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ShamirUnsealModal: React.FC<ShamirUnsealModalProps> = ({ isOpen, onClose }) => {
  const { cryptoState, submitShamirShare, resetShamirUnseal } = useVault();
  const [currentShareInput, setCurrentShareInput] = useState('');
  const [statusMessage, setStatusMessage] = useState<{ text: string; isError: boolean } | null>(null);

  if (!isOpen) return null;

  const sharesSubmittedCount = cryptoState.submittedShares.length;
  const remainingNeeded = Math.max(0, cryptoState.shamirThreshold - sharesSubmittedCount);

  const handleSubmit = (shareToSubmit?: string) => {
    const val = (shareToSubmit || currentShareInput).trim();
    if (!val) return;

    const res = submitShamirShare(val);
    if (!res.success) {
      setStatusMessage({ text: res.message, isError: true });
    } else {
      setStatusMessage({ text: res.message, isError: false });
      setCurrentShareInput('');
      if (res.remainingNeeded <= 0) {
        setTimeout(() => {
          onClose();
        }, 1200);
      }
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4">
      <div className="w-full max-w-xl rounded-xl border border-slate-800 bg-[#0F172A] p-6 shadow-2xl space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <Unlock className="h-5 w-5 text-amber-400" />
            <div>
              <h3 className="text-sm font-bold text-white">
                Shamir Multi-Party Vault Unseal
              </h3>
              <p className="text-xs text-slate-400">
                Requires {cryptoState.shamirThreshold} of {cryptoState.shamirTotalShares} custodian key shares to recompute AES-256 root master key.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white text-xs px-2 py-1 rounded bg-slate-800/80 cursor-pointer"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Progress indicator */}
        <div className="space-y-1.5 bg-slate-950 p-3 rounded-lg border border-slate-800">
          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-400 font-mono">
              Unseal Progress: <strong className="text-cyan-300 font-bold">{sharesSubmittedCount} / {cryptoState.shamirThreshold} Shares</strong>
            </span>
            <span className={`font-mono text-[11px] ${remainingNeeded === 0 ? 'text-emerald-400 font-bold' : 'text-amber-400'}`}>
              {remainingNeeded === 0 ? 'UNSEAL COMPLETE' : `${remainingNeeded} more needed`}
            </span>
          </div>

          <div className="h-2 w-full bg-slate-800 rounded-full overflow-hidden flex gap-1 p-0.5">
            {[1, 2, 3].map(step => (
              <div 
                key={step}
                className={`h-full flex-1 rounded-sm transition-all ${
                  sharesSubmittedCount >= step ? 'bg-cyan-400' : 'bg-slate-700/60'
                }`}
              />
            ))}
          </div>
        </div>

        {statusMessage && (
          <div className={`p-2.5 rounded-lg text-xs font-mono flex items-center gap-2 border ${
            statusMessage.isError 
              ? 'bg-rose-950/40 text-rose-300 border-rose-800/60' 
              : 'bg-emerald-950/40 text-emerald-300 border-emerald-800/60'
          }`}>
            {statusMessage.isError ? <AlertCircle className="h-4 w-4 shrink-0" /> : <Check className="h-4 w-4 shrink-0" />}
            <span>{statusMessage.text}</span>
          </div>
        )}

        {/* Input box */}
        <div className="space-y-2">
          <label className="block text-slate-300 font-medium text-xs">
            Enter Shamir Shard Key
          </label>
          <div className="flex gap-2">
            <input
              type="text"
              value={currentShareInput}
              onChange={(e) => setCurrentShareInput(e.target.value)}
              placeholder="e.g. aeg_key_share_1_8f93e0b9d5c4..."
              className="flex-1 rounded-lg border border-slate-800 bg-slate-950 px-3 py-2 text-xs font-mono text-slate-200 outline-none focus:border-cyan-500"
            />
            <button
              onClick={() => handleSubmit()}
              disabled={!currentShareInput.trim()}
              className="px-4 py-2 font-semibold text-xs text-slate-900 bg-cyan-400 hover:bg-cyan-300 rounded-lg transition-colors disabled:opacity-50 cursor-pointer"
            >
              Submit
            </button>
          </div>
        </div>

        {/* Quick Click Demo Shares for convenience */}
        <div className="space-y-1.5 pt-2">
          <span className="text-[11px] font-mono text-slate-500">
            Available Custodian Key Shards (Click to submit for testing):
          </span>
          <div className="space-y-1">
            {DEFAULT_SHAMIR_SHARES.slice(0, 3).map((share, idx) => {
              const isUsed = cryptoState.submittedShares.includes(share);
              return (
                <button
                  key={share}
                  onClick={() => handleSubmit(share)}
                  disabled={isUsed}
                  className={`w-full text-left p-2 rounded border font-mono text-[11px] flex items-center justify-between transition-all cursor-pointer ${
                    isUsed 
                      ? 'border-emerald-500/30 bg-emerald-950/20 text-emerald-300 opacity-60' 
                      : 'border-slate-800 bg-slate-900/60 hover:border-cyan-500/50 text-slate-300'
                  }`}
                >
                  <span className="truncate">Shard #{idx + 1}: {share}</span>
                  {isUsed ? (
                    <span className="text-[10px] text-emerald-400 font-bold shrink-0 ml-2">✓ SUBMITTED</span>
                  ) : (
                    <span className="text-[10px] text-cyan-400 font-bold shrink-0 ml-2">+ SUBMIT SHARD</span>
                  )}
                </button>
              );
            })}
          </div>
        </div>

        <div className="flex items-center justify-between pt-3 border-t border-slate-800 text-xs">
          <button
            onClick={resetShamirUnseal}
            className="text-slate-500 hover:text-slate-300"
          >
            Reset Progress
          </button>
          <button
            onClick={onClose}
            className="px-3 py-1.5 rounded text-slate-400 hover:text-white"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
