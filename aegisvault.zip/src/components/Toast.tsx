import React from 'react';
import { useVault } from '../context/VaultContext';
import { CheckCircle2, AlertTriangle, Info, AlertCircle, X } from 'lucide-react';

export const ToastContainer: React.FC = () => {
  const { toasts, removeToast } = useVault();

  if (toasts.length === 0) return null;

  return (
    <div className="fixed bottom-4 right-4 z-50 flex flex-col gap-2 max-w-sm w-full pointer-events-none">
      {toasts.map(toast => {
        return (
          <div
            key={toast.id}
            className={`pointer-events-auto flex items-start gap-3 p-3.5 rounded-xl border shadow-xl backdrop-blur-md transition-all animate-in fade-in slide-in-from-bottom-2 ${
              toast.type === 'success'
                ? 'border-emerald-500/30 bg-[#061814]/90 text-emerald-200'
                : toast.type === 'warning'
                  ? 'border-amber-500/30 bg-[#1c1404]/90 text-amber-200'
                  : toast.type === 'error'
                    ? 'border-rose-500/30 bg-[#1e070a]/90 text-rose-200'
                    : 'border-slate-700 bg-slate-900/90 text-slate-200'
            }`}
          >
            <div className="shrink-0 mt-0.5">
              {toast.type === 'success' && <CheckCircle2 className="h-4 w-4 text-emerald-400" />}
              {toast.type === 'warning' && <AlertTriangle className="h-4 w-4 text-amber-400" />}
              {toast.type === 'error' && <AlertCircle className="h-4 w-4 text-rose-400" />}
              {toast.type === 'info' && <Info className="h-4 w-4 text-cyan-400" />}
            </div>

            <div className="flex-1 text-xs">
              <div className="font-semibold text-slate-100">{toast.title}</div>
              <div className="text-slate-400 mt-0.5 leading-snug">{toast.message}</div>
            </div>

            <button
              onClick={() => removeToast(toast.id)}
              className="text-slate-500 hover:text-white shrink-0 p-0.5 cursor-pointer"
            >
              <X className="h-3.5 w-3.5" />
            </button>
          </div>
        );
      })}
    </div>
  );
};
