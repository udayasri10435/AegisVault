import React, { useState } from 'react';
import { useVault } from '../context/VaultContext';
import { Environment, RotationStrategy } from '../types/vault';
import { generateRandomSecret } from '../lib/cryptoUtils';
import { Key, Plus, Sparkles, X, Shield, Folder } from 'lucide-react';

interface NewSecretModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const NewSecretModal: React.FC<NewSecretModalProps> = ({ isOpen, onClose }) => {
  const { createSecret, selectedEnv } = useVault();

  const [name, setName] = useState('');
  const [path, setPath] = useState('core/app');
  const [environment, setEnvironment] = useState<Environment>(selectedEnv === 'all' ? 'production' : selectedEnv);
  const [value, setValue] = useState('');
  const [description, setDescription] = useState('');
  const [tagsInput, setTagsInput] = useState('');
  const [enableRotation, setEnableRotation] = useState(true);
  const [rotationInterval, setRotationInterval] = useState(30);
  const [rotationStrategy, setRotationStrategy] = useState<RotationStrategy>('crypto-random');

  if (!isOpen) return null;

  const handleGenerateEntropy = () => {
    setValue(generateRandomSecret(32, 'apikey'));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !value.trim()) return;

    const tags = tagsInput
      .split(',')
      .map(t => t.trim().toLowerCase())
      .filter(Boolean);

    const now = new Date().toISOString();
    const nextRotation = new Date(Date.now() + rotationInterval * 86400 * 1000).toISOString();

    createSecret({
      name: name.trim().toUpperCase(),
      path: path.trim().replace(/^\/|\/$/g, ''),
      environment,
      description: description.trim() || `Secret ${name.toUpperCase()}`,
      tags: tags.length > 0 ? tags : ['generic'],
      initialValue: value.trim(),
      rotationPolicy: {
        enabled: enableRotation,
        intervalDays: rotationInterval,
        autoRotate: true,
        lastRotatedAt: now,
        nextRotationAt: nextRotation,
        strategy: rotationStrategy,
        healthStatus: 'healthy'
      },
      status: 'active'
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4">
      <div className="w-full max-w-xl rounded-xl border border-slate-800 bg-[#0F172A] p-6 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <Key className="h-4 w-4 text-cyan-400" />
            <h3 className="text-sm font-bold text-white">
              Provision New Secret
            </h3>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded cursor-pointer"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-400 mb-1 font-medium">Secret Identifier Name</label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. STRIPE_API_SECRET"
                className="w-full rounded-lg border border-slate-800 bg-slate-950 px-3 py-2 text-slate-200 outline-none focus:border-cyan-500 font-mono"
              />
            </div>

            <div>
              <label className="block text-slate-400 mb-1 font-medium">Environment</label>
              <select
                value={environment}
                onChange={(e) => setEnvironment(e.target.value as any)}
                className="w-full rounded-lg border border-slate-800 bg-slate-950 px-3 py-2 text-slate-200 outline-none focus:border-cyan-500 font-mono"
              >
                <option value="production">Production</option>
                <option value="staging">Staging</option>
                <option value="development">Development</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-slate-400 mb-1 font-medium">Secret Path Folder</label>
            <div className="flex items-center gap-2 rounded-lg border border-slate-800 bg-slate-950 px-3 py-1.5">
              <Folder className="h-3.5 w-3.5 text-slate-500" />
              <input
                type="text"
                value={path}
                onChange={(e) => setPath(e.target.value)}
                placeholder="core/billing"
                className="w-full bg-transparent text-slate-200 outline-none font-mono text-xs"
              />
            </div>
          </div>

          {/* Secret Value input with Random Entropy Generator */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="text-slate-400 font-medium">Secret Value Payload</label>
              <button
                type="button"
                onClick={handleGenerateEntropy}
                className="flex items-center gap-1 text-[11px] text-cyan-400 hover:text-cyan-300 font-mono"
              >
                <Sparkles className="h-3 w-3" />
                <span>Generate High Entropy</span>
              </button>
            </div>
            <textarea
              required
              rows={3}
              value={value}
              onChange={(e) => setValue(e.target.value)}
              placeholder="Paste sensitive token, private key, or password..."
              className="w-full rounded-lg border border-slate-800 bg-slate-950 px-3 py-2 text-slate-200 font-mono text-xs outline-none focus:border-cyan-500"
            />
          </div>

          <div>
            <label className="block text-slate-400 mb-1 font-medium">Description</label>
            <input
              type="text"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Primary API credential for billing service"
              className="w-full rounded-lg border border-slate-800 bg-slate-950 px-3 py-2 text-slate-200 outline-none focus:border-cyan-500"
            />
          </div>

          <div>
            <label className="block text-slate-400 mb-1 font-medium">Tags (comma separated)</label>
            <input
              type="text"
              value={tagsInput}
              onChange={(e) => setTagsInput(e.target.value)}
              placeholder="billing, pci-dss, critical"
              className="w-full rounded-lg border border-slate-800 bg-slate-950 px-3 py-2 text-slate-200 outline-none focus:border-cyan-500 font-mono"
            />
          </div>

          {/* Automated Rotation Policy Section */}
          <div className="rounded-lg border border-slate-800 bg-slate-950 p-3 space-y-2">
            <div className="flex items-center justify-between">
              <div>
                <span className="font-semibold text-slate-200">Automated Rotation Policy</span>
                <p className="text-[11px] text-slate-400">Regularly roll credentials without code changes</p>
              </div>
              <button
                type="button"
                onClick={() => setEnableRotation(!enableRotation)}
                className={`w-10 h-5 rounded-full transition-colors relative cursor-pointer ${
                  enableRotation ? 'bg-cyan-500' : 'bg-slate-700'
                }`}
              >
                <div className={`w-3.5 h-3.5 rounded-full bg-white transition-transform absolute top-0.5 ${
                  enableRotation ? 'left-5' : 'left-1'
                }`} />
              </button>
            </div>

            {enableRotation && (
              <div className="grid grid-cols-2 gap-3 pt-2 border-t border-slate-800/80">
                <div>
                  <label className="block text-slate-400 mb-1 font-medium">Cadence</label>
                  <select
                    value={rotationInterval}
                    onChange={(e) => setRotationInterval(Number(e.target.value))}
                    className="w-full rounded-lg border border-slate-800 bg-slate-900 px-2.5 py-1.5 text-slate-200 font-mono"
                  >
                    <option value={7}>Every 7 Days</option>
                    <option value={14}>Every 14 Days</option>
                    <option value={30}>Every 30 Days</option>
                    <option value={90}>Every 90 Days</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-400 mb-1 font-medium">Strategy</label>
                  <select
                    value={rotationStrategy}
                    onChange={(e) => setRotationStrategy(e.target.value as any)}
                    className="w-full rounded-lg border border-slate-800 bg-slate-900 px-2.5 py-1.5 text-slate-200 font-mono"
                  >
                    <option value="crypto-random">Cryptographic Entropy</option>
                    <option value="database-role">PostgreSQL Role Swap</option>
                    <option value="aws-iam">AWS IAM Lifecycle</option>
                    <option value="webhook-hook">Microservice Webhook</option>
                  </select>
                </div>
              </div>
            )}
          </div>

          <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-3 py-1.5 text-slate-400 hover:text-white"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-1.5 font-semibold text-slate-900 bg-cyan-400 rounded-lg hover:bg-cyan-300 transition-colors"
            >
              Store Encrypted Secret
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
