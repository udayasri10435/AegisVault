import React, { useState } from 'react';
import { useVault } from '../context/VaultContext';
import { AuditLogEntry, AuditAction } from '../types/vault';
import { formatRelativeTime } from '../lib/cryptoUtils';
import { 
  ShieldCheck, 
  History, 
  Search, 
  Download, 
  Filter, 
  CheckCircle2, 
  AlertTriangle, 
  Terminal, 
  Globe, 
  Server, 
  Cpu, 
  FileText,
  Hash,
  ExternalLink,
  RefreshCw
} from 'lucide-react';

export const AuditLedger: React.FC = () => {
  const { 
    filteredAuditLogs, 
    auditFilterActor, 
    setAuditFilterActor, 
    auditFilterAction, 
    setAuditFilterAction,
    verifyAuditChainIntegrity,
    addToast
  } = useVault();

  const [inspectingEntry, setInspectingEntry] = useState<AuditLogEntry | null>(null);
  const [verificationResult, setVerificationResult] = useState<{ isValid: boolean; checkedBlocks: number; brokenBlockId?: string } | null>(null);
  const [isVerifying, setIsVerifying] = useState(false);

  // Available actions for filtering
  const actions: { id: string; label: string }[] = [
    { id: 'all', label: 'All Event Types' },
    { id: 'secret.read', label: 'secret.read' },
    { id: 'secret.rotate', label: 'secret.rotate' },
    { id: 'secret.update', label: 'secret.update' },
    { id: 'secret.create', label: 'secret.create' },
    { id: 'lease.issue', label: 'lease.issue' },
    { id: 'lease.revoke', label: 'lease.revoke' },
    { id: 'token.create', label: 'token.create' },
    { id: 'vault.unseal', label: 'vault.unseal' }
  ];

  const handleVerifyChain = () => {
    setIsVerifying(true);
    setTimeout(() => {
      const res = verifyAuditChainIntegrity();
      setVerificationResult(res);
      setIsVerifying(false);
      if (res.isValid) {
        addToast({
          type: 'success',
          title: 'Audit Chain Verified',
          message: `All ${res.checkedBlocks} cryptographic hash blocks verified successfully.`
        });
      }
    }, 600);
  };

  const handleExportCSV = () => {
    const headers = ['ID', 'Timestamp', 'Actor Name', 'Actor Email', 'Action', 'Resource', 'Environment', 'Client IP', 'Source', 'Block Hash'];
    const rows = filteredAuditLogs.map(l => [
      l.id,
      l.timestamp,
      `"${l.actor.name}"`,
      l.actor.email,
      l.action,
      `"${l.resource}"`,
      l.environment,
      l.clientIp,
      l.clientSource,
      l.tamperHash
    ]);

    const csvContent = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `aegis-vault-audit-trail-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    addToast({
      type: 'info',
      title: 'Audit CSV Exported',
      message: `Exported ${filteredAuditLogs.length} audit entries for compliance.`
    });
  };

  const getSourceIcon = (source: AuditLogEntry['clientSource']) => {
    switch (source) {
      case 'cli': return Terminal;
      case 'k8s-operator': return Server;
      case 'terraform': return Cpu;
      case 'sdk-python':
      case 'sdk-node': return FileText;
      default: return Globe;
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner: Tamper-Evident Merkle Chain Verification */}
      <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-4 sm:p-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <ShieldCheck className="h-4 w-4 text-cyan-400" />
            <h2 className="text-sm font-semibold text-slate-100">
              Tamper-Evident SHA-256 Audit Ledger
            </h2>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-950/60 text-cyan-300 border border-cyan-800/40">
              SOC 2 / ISO 27001 READY
            </span>
          </div>
          <p className="text-xs text-slate-400 max-w-2xl leading-relaxed">
            Every access event, rotation, secret unmask, and dynamic lease is committed to an immutable append-only hash chain. Each entry cryptographically anchors to the prior block's signature.
          </p>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={handleVerifyChain}
            disabled={isVerifying}
            className="flex items-center gap-2 px-3.5 py-1.5 text-xs font-semibold text-slate-900 bg-cyan-400 hover:bg-cyan-300 rounded-lg transition-colors cursor-pointer disabled:opacity-50"
          >
            <RefreshCw className={`h-3.5 w-3.5 ${isVerifying ? 'animate-spin' : ''}`} />
            <span>{isVerifying ? 'Verifying Chain...' : 'Verify Cryptographic Integrity'}</span>
          </button>

          <button
            onClick={handleExportCSV}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-300 bg-slate-800 hover:text-white border border-slate-700 rounded-lg transition-colors cursor-pointer"
          >
            <Download className="h-3.5 w-3.5 text-slate-400" />
            <span>Export CSV</span>
          </button>
        </div>
      </div>

      {/* Verification Status Notice if triggered */}
      {verificationResult && (
        <div className={`rounded-xl border p-4 flex items-center justify-between text-xs ${
          verificationResult.isValid 
            ? 'border-emerald-500/40 bg-emerald-950/20 text-emerald-300'
            : 'border-rose-500/40 bg-rose-950/20 text-rose-300'
        }`}>
          <div className="flex items-center gap-3">
            {verificationResult.isValid ? (
              <CheckCircle2 className="h-5 w-5 text-emerald-400 shrink-0" />
            ) : (
              <AlertTriangle className="h-5 w-5 text-rose-400 shrink-0" />
            )}
            <div>
              <div className="font-semibold text-slate-100">
                {verificationResult.isValid ? 'Chain Verification Succeeded' : 'Chain Integrity Violation Detected'}
              </div>
              <div className="text-[11px] text-slate-400 mt-0.5">
                {verificationResult.isValid 
                  ? `Recalculated SHA-256 hash chains across ${verificationResult.checkedBlocks} sequential blocks. 100% mathematical integrity intact.`
                  : `Block tampering detected at ID ${verificationResult.brokenBlockId}. Chain continuity broken.`
                }
              </div>
            </div>
          </div>

          <button 
            onClick={() => setVerificationResult(null)}
            className="text-slate-400 hover:text-white text-xs px-2 py-1"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Filter and Query Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2">
          {/* Action Filter */}
          <select
            value={auditFilterAction}
            onChange={(e) => setAuditFilterAction(e.target.value)}
            className="bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-300 font-mono text-xs outline-none focus:border-cyan-500"
          >
            {actions.map(act => (
              <option key={act.id} value={act.id}>{act.label}</option>
            ))}
          </select>

          {/* Actor Filter */}
          <select
            value={auditFilterActor}
            onChange={(e) => setAuditFilterActor(e.target.value)}
            className="bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-300 text-xs outline-none focus:border-cyan-500"
          >
            <option value="all">All Actors</option>
            <option value="user">Human Operators</option>
            <option value="service-token">Service Tokens (CI/CD)</option>
            <option value="system">Background Engines</option>
          </select>
        </div>

        <div className="text-slate-500 text-[11px] font-mono">
          Showing <span className="text-slate-300 font-bold">{filteredAuditLogs.length}</span> audit records
        </div>
      </div>

      {/* Audit Log Table */}
      <div className="rounded-xl border border-slate-800/80 bg-slate-900/40 overflow-hidden">
        {filteredAuditLogs.length === 0 ? (
          <div className="py-16 text-center text-xs text-slate-500">
            No audit records found matching current criteria.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-800/80 bg-slate-950/60 text-slate-400 text-[11px] uppercase tracking-wider font-mono">
                  <th className="py-2.5 px-4 font-medium">Timestamp</th>
                  <th className="py-2.5 px-4 font-medium">Actor</th>
                  <th className="py-2.5 px-3 font-medium">Action</th>
                  <th className="py-2.5 px-4 font-medium">Resource / Path</th>
                  <th className="py-2.5 px-3 font-medium">Source / IP</th>
                  <th className="py-2.5 px-4 font-medium">Tamper Hash Chain</th>
                  <th className="py-2.5 px-3 text-right font-medium">Details</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-sans">
                {filteredAuditLogs.map(log => {
                  const SourceIcon = getSourceIcon(log.clientSource);

                  return (
                    <tr 
                      key={log.id}
                      className="hover:bg-slate-800/30 transition-colors group cursor-pointer"
                      onClick={() => setInspectingEntry(log)}
                    >
                      {/* Timestamp */}
                      <td className="py-3 px-4 font-mono text-slate-300 whitespace-nowrap">
                        <div className="tabular-nums text-xs">
                          {formatRelativeTime(log.timestamp)}
                        </div>
                        <div className="text-[10px] text-slate-500 font-mono">
                          {log.timestamp.replace('T', ' ').slice(11, 19)} UTC
                        </div>
                      </td>

                      {/* Actor */}
                      <td className="py-3 px-4">
                        <div className="text-slate-200 font-medium text-xs">
                          {log.actor.name}
                        </div>
                        <div className="text-[11px] text-slate-500 font-mono truncate max-w-[150px]">
                          {log.actor.email}
                        </div>
                      </td>

                      {/* Action */}
                      <td className="py-3 px-3">
                        <span className={`font-mono text-[11px] px-2 py-0.5 rounded ${
                          log.action.includes('rotate') 
                            ? 'bg-cyan-500/10 text-cyan-300 border border-cyan-500/20'
                            : log.action.includes('revoke') || log.action.includes('delete')
                              ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                              : log.action.includes('issue')
                                ? 'bg-amber-500/10 text-amber-300 border border-amber-500/20'
                                : 'bg-slate-800 text-slate-300'
                        }`}>
                          {log.action}
                        </span>
                      </td>

                      {/* Resource */}
                      <td className="py-3 px-4 font-mono text-xs text-slate-300">
                        <div className="truncate max-w-[200px]" title={log.resource}>
                          {log.resource}
                        </div>
                        <div className="text-[10px] text-slate-500 capitalize">
                          env: {log.environment}
                        </div>
                      </td>

                      {/* Client Source & IP */}
                      <td className="py-3 px-3">
                        <div className="flex items-center gap-1.5 text-xs text-slate-300">
                          <SourceIcon className="h-3 w-3 text-slate-500" />
                          <span className="capitalize">{log.clientSource.replace('-', ' ')}</span>
                        </div>
                        <div className="text-[10px] text-slate-500 font-mono">
                          {log.clientIp}
                        </div>
                      </td>

                      {/* Tamper Hash Chain */}
                      <td className="py-3 px-4 font-mono text-[11px] text-slate-400">
                        <div className="flex items-center gap-1">
                          <Hash className="h-3 w-3 text-cyan-500/60" />
                          <span className="text-cyan-400/80">
                            {log.tamperHash.slice(0, 10)}...
                          </span>
                        </div>
                        <div className="text-[9px] text-slate-600 truncate max-w-[130px]">
                          parent: {log.prevHash.slice(0, 8)}...
                        </div>
                      </td>

                      {/* Details Drawer Trigger */}
                      <td className="py-3 px-3 text-right">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setInspectingEntry(log);
                          }}
                          className="text-xs text-slate-400 hover:text-cyan-400 underline font-mono"
                        >
                          inspect
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Inspect Audit Entry Drawer Modal */}
      {inspectingEntry && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
          <div className="w-full max-w-xl rounded-xl border border-slate-800 bg-[#0F172A] p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <ShieldCheck className="h-4 w-4 text-cyan-400" />
                  Audit Proof Block: <span className="font-mono text-cyan-300">{inspectingEntry.id}</span>
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Cryptographically chained audit verification record.
                </p>
              </div>
              <button
                onClick={() => setInspectingEntry(null)}
                className="text-slate-400 hover:text-white text-xs px-2 py-1 rounded bg-slate-800/80 cursor-pointer"
              >
                Close
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-3 bg-slate-950 p-3 rounded-lg border border-slate-800">
                <div>
                  <div className="text-slate-500 text-[10px] uppercase font-mono">Timestamp</div>
                  <div className="text-slate-200 font-mono mt-0.5">{inspectingEntry.timestamp}</div>
                </div>
                <div>
                  <div className="text-slate-500 text-[10px] uppercase font-mono">Action Type</div>
                  <div className="text-cyan-400 font-mono font-medium mt-0.5">{inspectingEntry.action}</div>
                </div>
                <div>
                  <div className="text-slate-500 text-[10px] uppercase font-mono">Actor</div>
                  <div className="text-slate-200 font-mono mt-0.5">{inspectingEntry.actor.email}</div>
                </div>
                <div>
                  <div className="text-slate-500 text-[10px] uppercase font-mono">Client IP & Source</div>
                  <div className="text-slate-200 font-mono mt-0.5">{inspectingEntry.clientIp} ({inspectingEntry.clientSource})</div>
                </div>
              </div>

              <div>
                <div className="text-slate-400 font-medium mb-1">Target Resource</div>
                <div className="bg-slate-950 p-2.5 rounded border border-slate-800 font-mono text-slate-200 break-all">
                  {inspectingEntry.resource}
                </div>
              </div>

              {inspectingEntry.diff?.details && (
                <div>
                  <div className="text-slate-400 font-medium mb-1">Event Payload & Diff Details</div>
                  <div className="bg-slate-950 p-2.5 rounded border border-slate-800 text-slate-300 font-mono text-xs leading-relaxed">
                    {inspectingEntry.diff.details}
                  </div>
                </div>
              )}

              {/* Cryptographic Chain Integrity Proof */}
              <div className="rounded-lg border border-cyan-500/20 bg-cyan-950/20 p-3 space-y-2">
                <div className="text-cyan-300 font-mono text-[11px] font-semibold flex items-center gap-1.5">
                  <Hash className="h-3.5 w-3.5" />
                  <span>Cryptographic Proof Linkage</span>
                </div>
                <div className="space-y-1 font-mono text-[11px]">
                  <div className="flex flex-col">
                    <span className="text-slate-500 text-[10px]">Previous Block Hash:</span>
                    <span className="text-slate-400 break-all">{inspectingEntry.prevHash}</span>
                  </div>
                  <div className="flex flex-col pt-1">
                    <span className="text-slate-500 text-[10px]">Block SHA-256 Hash Signature:</span>
                    <span className="text-emerald-400 break-all">{inspectingEntry.tamperHash}</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="flex justify-end pt-2 border-t border-slate-800">
              <button
                onClick={() => setInspectingEntry(null)}
                className="px-4 py-1.5 text-xs font-semibold text-slate-900 bg-cyan-400 rounded-lg hover:bg-cyan-300 transition-colors"
              >
                Close Inspector
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
