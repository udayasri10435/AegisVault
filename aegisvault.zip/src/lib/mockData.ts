import { Secret, DynamicEngineConfig, DynamicLease, AuditLogEntry, ServiceToken } from '../types/vault';
import { fastHash } from './cryptoUtils';

export const INITIAL_DYNAMIC_ENGINES: DynamicEngineConfig[] = [
  {
    id: 'postgresql',
    name: 'PostgreSQL Dynamic Roles',
    description: 'Generates just-in-time PostgreSQL database roles with custom privileges, automated password generation, and strict TTL lease enforcement.',
    defaultTtlSeconds: 3600, // 1 hour
    maxTtlSeconds: 86400, // 24 hours
    targetEndpoint: 'postgres://primary-pg.internal.aegis:5432/core_production',
    roleTemplates: ['read_only_analyst', 'read_write_app', 'ddl_migration_runner']
  },
  {
    id: 'aws-sts',
    name: 'AWS STS (AssumeRole)',
    description: 'Mints short-lived AWS IAM credentials (AccessKeyId, SecretAccessKey, SessionToken) mapped to configured IAM policies.',
    defaultTtlSeconds: 3600,
    maxTtlSeconds: 43200, // 12 hours
    targetEndpoint: 'arn:aws:iam::123456789012:role/aegis-production-runner',
    roleTemplates: ['s3_read_archive', 'sqs_publish_worker', 'ecs_deploy_agent']
  },
  {
    id: 'redis',
    name: 'Redis ACL Ephemeral Tokens',
    description: 'Creates temporary Redis ACL credentials with scoped keyspace patterns and auto-expiring connection leases.',
    defaultTtlSeconds: 1800, // 30 min
    maxTtlSeconds: 7200,
    targetEndpoint: 'rediss://cache-cluster.internal.aegis:6379',
    roleTemplates: ['cache_read_sessions', 'cache_write_temporary', 'pubsub_listener']
  },
  {
    id: 'github',
    name: 'GitHub Repository Deploy Token',
    description: 'Generates on-demand fine-grained GitHub installation access tokens for CI/CD runners with strict scope isolation.',
    defaultTtlSeconds: 1800,
    maxTtlSeconds: 28800,
    targetEndpoint: 'github.com/aegis-enterprise/core-services',
    roleTemplates: ['contents_read', 'packages_write', 'deployments_create']
  }
];

export const INITIAL_SECRETS: Secret[] = [
  {
    id: 'sec_01',
    name: 'DATABASE_URL',
    path: 'core/database/primary',
    environment: 'production',
    currentVersion: 4,
    description: 'Primary PostgreSQL connection string with SSL pooling parameters and read replicas',
    tags: ['database', 'postgres', 'critical', 'tier-0'],
    createdAt: '2026-08-10T12:00:00Z',
    updatedAt: '2026-09-24T18:30:00Z',
    status: 'active',
    rotationPolicy: {
      enabled: true,
      intervalDays: 30,
      autoRotate: true,
      lastRotatedAt: '2026-09-24T18:30:00Z',
      nextRotationAt: '2026-10-24T18:30:00Z',
      strategy: 'database-role',
      webhookUrl: 'https://api.internal.aegis/hooks/rotate-pg-primary',
      healthStatus: 'healthy'
    },
    versions: [
      {
        version: 4,
        value: 'postgresql://aeg_db_master:K8x9#mP$2vLq7wZb@db-prod-primary.us-east-1.rds.amazonaws.com:5432/core_prod?sslmode=verify-full&pool_max=50',
        createdAt: '2026-09-24T18:30:00Z',
        author: 'AutoRotationPolicyEngine',
        changeReason: 'Scheduled 30-day credential rotation via Postgres role swap hook',
        checksum: 'sha256:7f39b1a2...'
      },
      {
        version: 3,
        value: 'postgresql://aeg_db_master:N2y7@qR!9wKc4vXm@db-prod-primary.us-east-1.rds.amazonaws.com:5432/core_prod?sslmode=verify-full',
        createdAt: '2026-08-25T18:30:00Z',
        author: 'AutoRotationPolicyEngine',
        changeReason: 'Scheduled 30-day credential rotation',
        checksum: 'sha256:5a12d9f4...'
      },
      {
        version: 2,
        value: 'postgresql://aeg_db_master:H6p3#kL$8rTm1wQz@db-prod-primary.us-east-1.rds.amazonaws.com:5432/core_prod?sslmode=verify-full',
        createdAt: '2026-07-26T18:30:00Z',
        author: 'elena.rostova@aegis.corp',
        changeReason: 'Updated SSL parameters and connection pooling limit',
        checksum: 'sha256:3c88e0a1...'
      },
      {
        version: 1,
        value: 'postgresql://aeg_db_master:B1t9*xM$4zLp2wKq@db-prod-primary.us-east-1.rds.amazonaws.com:5432/core_prod',
        createdAt: '2026-06-26T14:10:00Z',
        author: 'marcus.vance@aegis.corp',
        changeReason: 'Initial vault secret provisioning for v2 migration',
        checksum: 'sha256:1a99c4d2...'
      }
    ]
  },
  {
    id: 'sec_02',
    name: 'STRIPE_SECRET_KEY',
    path: 'billing/stripe/live',
    environment: 'production',
    currentVersion: 2,
    description: 'Production Stripe live secret API key for billing and subscription processing',
    tags: ['billing', 'stripe', 'finance', 'pci-dss'],
    createdAt: '2026-07-01T09:00:00Z',
    updatedAt: '2026-09-01T10:15:00Z',
    status: 'active',
    rotationPolicy: {
      enabled: true,
      intervalDays: 90,
      autoRotate: false,
      lastRotatedAt: '2026-09-01T10:15:00Z',
      nextRotationAt: '2026-11-30T10:15:00Z',
      strategy: 'webhook-hook',
      webhookUrl: 'https://billing.internal.aegis/v1/rotate-stripe',
      healthStatus: 'healthy'
    },
    versions: [
      {
        version: 2,
        value: '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',
        createdAt: '2026-09-01T10:15:00Z',
        author: 'sarah.lin@aegis.corp',
        changeReason: 'Quarterly compliance rotation',
        checksum: 'sha256:8b45c2e1...'
      },
      {
        version: 1,
        value: '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',
        createdAt: '2026-07-01T09:00:00Z',
        author: 'sarah.lin@aegis.corp',
        changeReason: 'Initial setup for Stripe billing engine',
        checksum: 'sha256:2f99a3b4...'
      }
    ]
  },
  {
    id: 'sec_03',
    name: 'JWT_SIGNING_PRIVATE_KEY',
    path: 'auth/jwt/rs256',
    environment: 'production',
    currentVersion: 3,
    description: 'RSA 4096-bit private key PEM used for signing user session JWT tokens',
    tags: ['auth', 'crypto', 'jwt', 'security'],
    createdAt: '2026-06-15T08:00:00Z',
    updatedAt: '2026-09-28T14:20:00Z',
    status: 'active',
    rotationPolicy: {
      enabled: true,
      intervalDays: 14,
      autoRotate: true,
      lastRotatedAt: '2026-09-14T14:20:00Z',
      nextRotationAt: '2026-09-28T14:20:00Z',
      strategy: 'crypto-random',
      healthStatus: 'due'
    },
    versions: [
      {
        version: 3,
        value: '-----BEGIN RSA PRIVATE KEY-----\nMIIEowIBAAKCAQEA0sQ7zHw3P0...[RSA-4096 PEM PRIVATE KEY]...9KxM8v=\n-----END RSA PRIVATE KEY-----',
        createdAt: '2026-09-14T14:20:00Z',
        author: 'AutoRotationPolicyEngine',
        changeReason: 'Bi-weekly automated key rotation with dual-verification grace period',
        checksum: 'sha256:6e11b2c3...'
      },
      {
        version: 2,
        value: '-----BEGIN RSA PRIVATE KEY-----\nMIIEowIBAAKCAQEA3aB7xLw8N2...[PREVIOUS RS256 PEM]...7PvR2w=\n-----END RSA PRIVATE KEY-----',
        createdAt: '2026-08-31T14:20:00Z',
        author: 'AutoRotationPolicyEngine',
        changeReason: 'Bi-weekly automated key rotation',
        checksum: 'sha256:4d89a7f2...'
      }
    ]
  },
  {
    id: 'sec_04',
    name: 'AWS_SECRET_ACCESS_KEY',
    path: 'cloud/aws/iam_prod_deployer',
    environment: 'production',
    currentVersion: 1,
    description: 'IAM credentials for AWS Terraform CI/CD automated deployment agent',
    tags: ['aws', 'iam', 'infra'],
    createdAt: '2026-06-01T10:00:00Z',
    updatedAt: '2026-06-01T10:00:00Z',
    status: 'rotation-pending',
    rotationPolicy: {
      enabled: true,
      intervalDays: 60,
      autoRotate: false,
      lastRotatedAt: '2026-06-01T10:00:00Z',
      nextRotationAt: '2026-08-01T10:00:00Z',
      strategy: 'aws-iam',
      healthStatus: 'overdue'
    },
    versions: [
      {
        version: 1,
        value: 'wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY89',
        createdAt: '2026-06-01T10:00:00Z',
        author: 'devops-lead@aegis.corp',
        changeReason: 'Initial IAM deployer user credential provisioning',
        checksum: 'sha256:9c88a1b2...'
      }
    ]
  },
  {
    id: 'sec_05',
    name: 'OPENAI_API_KEY',
    path: 'ai/openai/gateway',
    environment: 'production',
    currentVersion: 2,
    description: 'Organization API key for LLM semantic analysis and summarization pipelines',
    tags: ['ai', 'llm', 'external-api'],
    createdAt: '2026-08-05T11:00:00Z',
    updatedAt: '2026-09-15T09:30:00Z',
    status: 'active',
    rotationPolicy: {
      enabled: true,
      intervalDays: 60,
      autoRotate: false,
      lastRotatedAt: '2026-09-15T09:30:00Z',
      nextRotationAt: '2026-11-15T09:30:00Z',
      strategy: 'crypto-random',
      healthStatus: 'healthy'
    },
    versions: [
      {
        version: 2,
        value: 'sk-proj-7x89q2w1e4r5t6y7u8i9o0p1a2s3d4f5g6h7j8k9l0z1x2c3v4b5n6m7',
        createdAt: '2026-09-15T09:30:00Z',
        author: 'elena.rostova@aegis.corp',
        changeReason: 'Rotated key after tier upgrade to enterprise throughput',
        checksum: 'sha256:3a14e9f7...'
      }
    ]
  },
  {
    id: 'sec_06',
    name: 'DATABASE_URL',
    path: 'core/database/primary',
    environment: 'staging',
    currentVersion: 2,
    description: 'Staging PostgreSQL cluster database connection string',
    tags: ['database', 'postgres', 'staging'],
    createdAt: '2026-08-01T10:00:00Z',
    updatedAt: '2026-09-20T11:00:00Z',
    status: 'active',
    rotationPolicy: {
      enabled: true,
      intervalDays: 30,
      autoRotate: true,
      lastRotatedAt: '2026-09-20T11:00:00Z',
      nextRotationAt: '2026-10-20T11:00:00Z',
      strategy: 'database-role',
      healthStatus: 'healthy'
    },
    versions: [
      {
        version: 2,
        value: 'postgresql://aeg_staging_user:StgP@ss982#kLm@db-staging.us-east-1.rds.amazonaws.com:5432/core_staging?sslmode=require',
        createdAt: '2026-09-20T11:00:00Z',
        author: 'AutoRotationPolicyEngine',
        changeReason: 'Monthly staging auto-rotation',
        checksum: 'sha256:7b11a9e8...'
      }
    ]
  },
  {
    id: 'sec_07',
    name: 'SLACK_WEBHOOK_URL',
    path: 'alerts/slack/incident-ops',
    environment: 'staging',
    currentVersion: 1,
    description: 'Slack incoming webhook for alerting and ops notifications',
    tags: ['notifications', 'slack', 'ops'],
    createdAt: '2026-08-15T14:00:00Z',
    updatedAt: '2026-08-15T14:00:00Z',
    status: 'active',
    rotationPolicy: {
      enabled: false,
      intervalDays: 180,
      autoRotate: false,
      lastRotatedAt: '2026-08-15T14:00:00Z',
      nextRotationAt: '2027-02-15T14:00:00Z',
      strategy: 'webhook-hook',
      healthStatus: 'healthy'
    },
    versions: [
      {
        version: 1,
        value: 'https://hooks.slack.com/services/T00000000/B00000000/XXXXXXXXXXXXXXXXXXXXXXXX',
        createdAt: '2026-08-15T14:00:00Z',
        author: 'marcus.vance@aegis.corp',
        changeReason: 'Initial setup for staging deployment alerts',
        checksum: 'sha256:5e22c8a1...'
      }
    ]
  },
  {
    id: 'sec_08',
    name: 'REDIS_AUTH_TOKEN',
    path: 'cache/redis/primary',
    environment: 'development',
    currentVersion: 1,
    description: 'Local development Redis instance auth password',
    tags: ['redis', 'cache', 'dev'],
    createdAt: '2026-09-01T08:00:00Z',
    updatedAt: '2026-09-01T08:00:00Z',
    status: 'active',
    rotationPolicy: {
      enabled: false,
      intervalDays: 30,
      autoRotate: false,
      lastRotatedAt: '2026-09-01T08:00:00Z',
      nextRotationAt: '2026-10-01T08:00:00Z',
      strategy: 'crypto-random',
      healthStatus: 'healthy'
    },
    versions: [
      {
        version: 1,
        value: 'dev_redis_auth_9f83a2b1c4e5d6',
        createdAt: '2026-09-01T08:00:00Z',
        author: 'elena.rostova@aegis.corp',
        changeReason: 'Local dev sandbox configuration',
        checksum: 'sha256:4c11b0e9...'
      }
    ]
  }
];

// Active dynamic leases with countdowns
export const INITIAL_DYNAMIC_LEASES: DynamicLease[] = [
  {
    leaseId: 'lease_pg_782f9c0b',
    engine: 'postgresql',
    targetResource: 'cluster-primary.internal:5432/core_production',
    username: 'v_db_u_782f9c',
    credentials: {
      username: 'v_db_u_782f9c',
      password: 'p_dyn_K9#xL2$vM8qW',
      connectionString: 'postgresql://v_db_u_782f9c:p_dyn_K9%23xL2%24vM8qW@cluster-primary.internal:5432/core_production?sslmode=verify-full'
    },
    issuedAt: new Date(Date.now() - 18 * 60 * 1000).toISOString(),
    expiresAt: new Date(Date.now() + 42 * 60 * 1000).toISOString(),
    ttlSeconds: 3600,
    status: 'active',
    role: 'read_only_analyst',
    requestedBy: 'sarah.lin@aegis.corp',
    clientIp: '192.168.1.104'
  },
  {
    leaseId: 'lease_aws_3b91a7e2',
    engine: 'aws-sts',
    targetResource: 'arn:aws:iam::123456789012:role/aegis-production-runner',
    username: 'aegis-session-3b91a7',
    credentials: {
      AccessKeyId: 'ASIAV4EXAMPLE901234',
      SecretAccessKey: 'qZ8yW2vM9kL4pT7xR1bN3cE5gH6jK8mN0pQ2rS4t',
      SessionToken: 'IQoJb3JpZ2luX2VjEBEaCXVzLWVhc3QtMSJHMEUCIQD6...[SESSION_TOKEN]...=='
    },
    issuedAt: new Date(Date.now() - 35 * 60 * 1000).toISOString(),
    expiresAt: new Date(Date.now() + 25 * 60 * 1000).toISOString(),
    ttlSeconds: 3600,
    status: 'active',
    role: 's3_read_archive',
    requestedBy: 'k8s-pod/worker-exporter-7b9d',
    clientIp: '10.244.3.45'
  },
  {
    leaseId: 'lease_red_5c12e8a9',
    engine: 'redis',
    targetResource: 'rediss://cache-cluster.internal.aegis:6379',
    username: 'v_redis_u_5c12',
    credentials: {
      username: 'v_redis_u_5c12',
      password: 'r_dyn_pwd_9a8b7c6d5e4f3a2b',
      allowedKeyspace: 'session:cache:*'
    },
    issuedAt: new Date(Date.now() - 55 * 60 * 1000).toISOString(),
    expiresAt: new Date(Date.now() + 5 * 60 * 1000).toISOString(),
    ttlSeconds: 3600,
    status: 'active',
    role: 'cache_read_sessions',
    requestedBy: 'elena.rostova@aegis.corp',
    clientIp: '192.168.1.88'
  },
  {
    leaseId: 'lease_gh_1a89f4b0',
    engine: 'github',
    targetResource: 'github.com/aegis-enterprise/core-services',
    username: 'gh_deploy_1a89',
    credentials: {
      token: 'ghs_dyn_7A8b9C0d1E2f3G4h5I6j7K8l9M0n1O2p3Q4r',
      scope: 'contents:read, deployments:write'
    },
    issuedAt: new Date(Date.now() - 120 * 60 * 1000).toISOString(),
    expiresAt: new Date(Date.now() - 60 * 60 * 1000).toISOString(),
    ttlSeconds: 3600,
    status: 'expired',
    role: 'deployments_create',
    requestedBy: 'ci-runner-eu-west-1',
    clientIp: '54.216.89.12'
  }
];

// Seeded verifiable cryptographic audit log chain
const GENESIS_HASH = '0000000000000000000000000000000000000000000000000000000000000000';

function buildChainEntry(
  prevHash: string,
  entry: Omit<AuditLogEntry, 'prevHash' | 'tamperHash'>
): AuditLogEntry {
  const payload = `${prevHash}|${entry.id}|${entry.timestamp}|${entry.actor.email}|${entry.action}|${entry.resource}`;
  const tamperHash = fastHash(payload);
  return {
    ...entry,
    prevHash,
    tamperHash
  };
}

const e1 = buildChainEntry(GENESIS_HASH, {
  id: 'aud_001',
  timestamp: '2026-09-24T18:30:00Z',
  actor: { name: 'AutoRotationEngine', email: 'system@aegisvault.internal', type: 'system' },
  action: 'secret.rotate',
  resource: 'core/database/primary',
  environment: 'production',
  clientIp: '127.0.0.1',
  clientSource: 'k8s-operator',
  diff: { details: 'Rotated DATABASE_URL from v3 to v4 via Postgres role swap hook' },
  status: 'success'
});

const e2 = buildChainEntry(e1.tamperHash, {
  id: 'aud_002',
  timestamp: '2026-09-25T09:14:22Z',
  actor: { name: 'Elena Rostova', email: 'elena.rostova@aegis.corp', type: 'user' },
  action: 'secret.read',
  resource: 'billing/stripe/live',
  environment: 'production',
  clientIp: '192.168.1.88',
  clientSource: 'web-console',
  diff: { details: 'Unmasked secret value in Web UI with 15s session grant' },
  status: 'success'
});

const e3 = buildChainEntry(e2.tamperHash, {
  id: 'aud_003',
  timestamp: '2026-09-26T14:02:11Z',
  actor: { name: 'GitHub Actions Prod Runner', email: 'ci-bot@aegis.corp', type: 'service-token' },
  action: 'secret.read',
  resource: 'auth/jwt/rs256',
  environment: 'production',
  clientIp: '52.14.99.112',
  clientSource: 'cli',
  diff: { details: 'Pulled secret via CLI command: aegis pull --env prod' },
  status: 'success'
});

const e4 = buildChainEntry(e3.tamperHash, {
  id: 'aud_004',
  timestamp: '2026-09-27T10:45:00Z',
  actor: { name: 'Sarah Lin', email: 'sarah.lin@aegis.corp', type: 'user' },
  action: 'lease.issue',
  resource: 'postgresql:cluster-primary.internal:5432/core_production',
  environment: 'production',
  clientIp: '192.168.1.104',
  clientSource: 'web-console',
  diff: { details: 'Granted dynamic lease lease_pg_782f9c0b (role: read_only_analyst, TTL: 3600s)' },
  status: 'success'
});

const e5 = buildChainEntry(e4.tamperHash, {
  id: 'aud_005',
  timestamp: '2026-09-28T16:20:30Z',
  actor: { name: 'Marcus Vance', email: 'marcus.vance@aegis.corp', type: 'user' },
  action: 'token.create',
  resource: 'tokens/svc_tok_k8s_worker',
  environment: 'global',
  clientIp: '192.168.1.72',
  clientSource: 'web-console',
  diff: { details: 'Created service token with scoped policy: [read, dynamic_issue] on path prod/*' },
  status: 'success'
});

export const INITIAL_AUDIT_LOGS: AuditLogEntry[] = [e5, e4, e3, e2, e1];

export const INITIAL_SERVICE_TOKENS: ServiceToken[] = [
  {
    id: 'tok_01',
    name: 'CI/CD GitHub Actions Deployer',
    tokenPrefix: 'aeg_live_tok_gha_9f82',
    createdAt: '2026-08-12T10:00:00Z',
    lastUsedAt: '2026-09-28T14:10:00Z',
    expiresAt: '2027-08-12T10:00:00Z',
    environmentScope: 'all',
    pathPattern: '*',
    policies: ['read', 'rotate'],
    status: 'active'
  },
  {
    id: 'tok_02',
    name: 'Kubernetes External Secrets Operator',
    tokenPrefix: 'aeg_live_tok_k8s_4c11',
    createdAt: '2026-08-20T09:30:00Z',
    lastUsedAt: '2026-09-29T00:01:15Z',
    expiresAt: null,
    environmentScope: 'production',
    pathPattern: 'core/*',
    policies: ['read', 'dynamic_issue'],
    status: 'active'
  },
  {
    id: 'tok_03',
    name: 'Staging Worker Daemon',
    tokenPrefix: 'aeg_live_tok_stg_7b33',
    createdAt: '2026-09-01T15:00:00Z',
    lastUsedAt: '2026-09-25T11:20:00Z',
    expiresAt: '2026-12-01T15:00:00Z',
    environmentScope: 'staging',
    pathPattern: 'staging/*',
    policies: ['read'],
    status: 'active'
  },
  {
    id: 'tok_04',
    name: 'Deprecated Dev Laptop Token',
    tokenPrefix: 'aeg_live_tok_dev_1e99',
    createdAt: '2026-06-01T11:00:00Z',
    lastUsedAt: '2026-07-15T09:00:00Z',
    expiresAt: '2026-09-01T11:00:00Z',
    environmentScope: 'development',
    pathPattern: 'development/*',
    policies: ['read', 'write'],
    status: 'revoked'
  }
];
