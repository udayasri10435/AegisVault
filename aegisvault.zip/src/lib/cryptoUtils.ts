/**
 * Cryptographic & hashing utilities for AegisVault
 * Implements SHA-256 Merkle chain linking and entropy generation
 */

// Compute real SHA-256 hash using browser WebCrypto
export async function sha256(message: string): Promise<string> {
  const msgBuffer = new TextEncoder().encode(message);
  const hashBuffer = await crypto.subtle.digest('SHA-256', msgBuffer);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

// Synchronous fast fallback / mock hash for instant state computation
export function fastHash(str: string): string {
  let hash = 0x811c9dc5;
  for (let i = 0; i < str.length; i++) {
    hash ^= str.charCodeAt(i);
    hash += (hash << 1) + (hash << 4) + (hash << 7) + (hash << 8) + (hash << 24);
  }
  return ('00000000' + (hash >>> 0).toString(16)).slice(-8) + 
         ('00000000' + ((hash * 31) >>> 0).toString(16)).slice(-8) +
         ('00000000' + ((hash * 17) >>> 0).toString(16)).slice(-8) +
         ('00000000' + ((hash * 19) >>> 0).toString(16)).slice(-8);
}

// Generate secure random strings for secrets and tokens
export function generateRandomSecret(length = 32, type: 'hex' | 'alphanumeric' | 'base64' | 'apikey' = 'apikey'): string {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  const array = new Uint8Array(length);
  crypto.getRandomValues(array);
  
  if (type === 'hex') {
    return Array.from(array).map(b => b.toString(16).padStart(2, '0')).join('').slice(0, length);
  }
  
  if (type === 'apikey') {
    const randomBody = Array.from(array).map(x => chars[x % chars.length]).join('').slice(0, length);
    return `aeg_sec_${randomBody}`;
  }
  
  return Array.from(array).map(x => chars[x % chars.length]).join('').slice(0, length);
}

// Generate dynamic credentials for database roles
export function generateDynamicDbCredential(prefix = 'v_db_u'): { username: string; password: string; connectionString: string } {
  const randomSuffix = generateRandomSecret(6, 'hex');
  const username = `${prefix}_${randomSuffix}`;
  const password = generateRandomSecret(24, 'alphanumeric');
  const connectionString = `postgresql://${username}:${password}@primary-pg.internal.aegis:5432/core_production?sslmode=verify-full`;
  return { username, password, connectionString };
}

// Generate dynamic AWS STS temporary token
export function generateDynamicAwsCredential(): { accessKeyId: string; secretAccessKey: string; sessionToken: string; expiration: string } {
  const accessKeyId = `ASIA${generateRandomSecret(16, 'alphanumeric').toUpperCase()}`;
  const secretAccessKey = generateRandomSecret(40, 'alphanumeric');
  const sessionToken = `IQoJb3JpZ2luX2VjEBEaCXVzLWVhc3QtMSJHMEUCIQ${generateRandomSecret(48, 'base64')}`;
  const expiration = new Date(Date.now() + 3600 * 1000).toISOString();
  return { accessKeyId, secretAccessKey, sessionToken, expiration };
}

// Mask secret string
export function maskSecret(val: string): string {
  if (!val) return '••••••••••••••••';
  if (val.length <= 8) return '••••••••';
  return val.slice(0, 4) + '•'.repeat(Math.min(val.length - 8, 20)) + val.slice(-4);
}

// Format relative time or ISO date cleanly
export function formatRelativeTime(dateString: string): string {
  const date = new Date(dateString);
  const now = new Date();
  const diffSec = Math.floor((now.getTime() - date.getTime()) / 1000);
  
  if (diffSec < 60) return `${Math.max(1, diffSec)}s ago`;
  if (diffSec < 3600) return `${Math.floor(diffSec / 60)}m ago`;
  if (diffSec < 86400) return `${Math.floor(diffSec / 3600)}h ago`;
  if (diffSec < 86400 * 30) return `${Math.floor(diffSec / 86400)}d ago`;
  return date.toISOString().split('T')[0];
}

// Format future countdown
export function formatCountdown(dateString: string): { label: string; isPast: boolean; percent: number } {
  const target = new Date(dateString).getTime();
  const now = Date.now();
  const diffMs = target - now;
  
  if (diffMs <= 0) {
    return { label: 'Expired', isPast: true, percent: 100 };
  }
  
  const diffSec = Math.floor(diffMs / 1000);
  const hours = Math.floor(diffSec / 3600);
  const minutes = Math.floor((diffSec % 3600) / 60);
  const seconds = diffSec % 60;
  
  if (hours > 24) {
    const days = Math.floor(hours / 24);
    return { label: `in ${days}d ${hours % 24}h`, isPast: false, percent: Math.max(5, 100 - (days * 10)) };
  }
  
  const label = hours > 0 
    ? `${hours}h ${minutes.toString().padStart(2, '0')}m`
    : `${minutes}m ${seconds.toString().padStart(2, '0')}s`;
    
  return { label, isPast: false, percent: Math.min(100, Math.max(0, 100 - (diffSec / 36))) };
}

// Initial Shamir 5-part key shares (3 of 5 needed to unseal)
export const DEFAULT_SHAMIR_SHARES = [
  'aeg_key_share_1_8f93e0b9d5c4a3b2e1f0789a',
  'aeg_key_share_2_4c71b8e2a0f9d3c5e6b41298',
  'aeg_key_share_3_9e24d7a1c8f0b5e3a6c27184',
  'aeg_key_share_4_1b58f0c3d9e2a7b4c6e09325',
  'aeg_key_share_5_7a39e1c4b8f0d2a5c6e84910'
];
