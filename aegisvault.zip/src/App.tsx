/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { VaultProvider, useVault } from './context/VaultContext';
import { Header } from './components/Header';
import { Navigation } from './components/Navigation';
import { SecretsManager } from './components/SecretsManager';
import { DynamicSecrets } from './components/DynamicSecrets';
import { RotationHub } from './components/RotationHub';
import { AuditLedger } from './components/AuditLedger';
import { ServiceTokens } from './components/ServiceTokens';
import { DeveloperPlayground } from './components/DeveloperPlayground';
import { VaultCryptoInspector } from './components/VaultCryptoInspector';
import { NewSecretModal } from './components/NewSecretModal';
import { MintLeaseModal } from './components/MintLeaseModal';
import { ShamirUnsealModal } from './components/ShamirUnsealModal';
import { CommandPalette } from './components/CommandPalette';
import { ToastContainer } from './components/Toast';

const VaultDashboard: React.FC = () => {
  const { currentTab } = useVault();
  
  const [isNewSecretModalOpen, setIsNewSecretModalOpen] = useState(false);
  const [isDynamicModalOpen, setIsDynamicModalOpen] = useState(false);
  const [isShamirModalOpen, setIsShamirModalOpen] = useState(false);

  return (
    <div className="min-h-screen bg-[#090D16] text-slate-100 flex flex-col font-sans selection:bg-cyan-500/20 selection:text-cyan-300">
      {/* Global Top Bar */}
      <Header
        onOpenNewSecretModal={() => setIsNewSecretModalOpen(true)}
        onOpenDynamicModal={() => setIsDynamicModalOpen(true)}
        onOpenShamirModal={() => setIsShamirModalOpen(true)}
      />

      {/* Primary Tab Navigation */}
      <Navigation />

      {/* Main Content Area */}
      <main className="flex-1 w-full max-w-7xl mx-auto px-4 sm:px-6 py-6">
        {currentTab === 'secrets' && (
          <SecretsManager
            onOpenNewSecretModal={() => setIsNewSecretModalOpen(true)}
            onOpenShamirModal={() => setIsShamirModalOpen(true)}
          />
        )}

        {currentTab === 'dynamic' && (
          <DynamicSecrets
            onOpenMintModal={() => setIsDynamicModalOpen(true)}
          />
        )}

        {currentTab === 'rotation' && (
          <RotationHub />
        )}

        {currentTab === 'audit' && (
          <AuditLedger />
        )}

        {currentTab === 'tokens' && (
          <ServiceTokens />
        )}

        {currentTab === 'cli-sdk' && (
          <DeveloperPlayground />
        )}

        {currentTab === 'crypto' && (
          <VaultCryptoInspector
            onOpenShamirModal={() => setIsShamirModalOpen(true)}
          />
        )}
      </main>

      {/* Modals & Overlays */}
      <NewSecretModal
        isOpen={isNewSecretModalOpen}
        onClose={() => setIsNewSecretModalOpen(false)}
      />

      <MintLeaseModal
        isOpen={isDynamicModalOpen}
        onClose={() => setIsDynamicModalOpen(false)}
      />

      <ShamirUnsealModal
        isOpen={isShamirModalOpen}
        onClose={() => setIsShamirModalOpen(false)}
      />

      <CommandPalette
        onOpenNewSecretModal={() => setIsNewSecretModalOpen(true)}
        onOpenDynamicModal={() => setIsDynamicModalOpen(true)}
        onOpenShamirModal={() => setIsShamirModalOpen(true)}
      />

      <ToastContainer />
    </div>
  );
};

export default function App() {
  return (
    <VaultProvider>
      <VaultDashboard />
    </VaultProvider>
  );
}
