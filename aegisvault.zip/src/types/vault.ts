export type Environment = 'production' | 'staging' | 'development';

export interface SecretVersion {
  version: number;
  value: string;
  createdAt: string;
  author: string;
  changeReason: string;
  checksum: string;
}

export type RotationStrategy = 'crypto-random' | 'database-role' | 'aws-iam' | 'oauth-refresh' | 'webhook-hook';

export interface RotationPolicy {
  enabled: boolean;
  intervalDays: number;
  autoRotate: boolean;
  lastRotatedAt: string;
  nextRotationAt: string;
  strategy: RotationStrategy;
  webhookUrl?: string;
  healthStatus: 'healthy' | 'due' | 'overdue' | 'failed';
}

export interface Secret {
  id: string;
  name: string;
  path: string;
  environment: Environment;
  currentVersion: number;
  versions: SecretVersion[];
  rotationPolicy: RotationPolicy;
  tags: string[];
  description: string;
  updatedAt: string;
  createdAt: string;
  status: 'active' | 'rotation-pending' | 'deprecated';
}

export type DynamicEngineType = 'postgresql' | 'aws-sts' | 'redis' | 'github';

export interface DynamicEngineConfig {
  id: DynamicEngineType;
  name: string;
  description: string;
  defaultTtlSeconds: number;
  maxTtlSeconds: number;
  targetEndpoint: string;
  roleTemplates: string[];
}

export interface DynamicLease {
  leaseId: string;
  engine: DynamicEngineType;
  targetResource: string;
  username: string;
  credentials: Record<string, string>;
  issuedAt: string;
  expiresAt: string;
  ttlSeconds: number;
  status: 'active' | 'renewed' | 'revoked' | 'expired';
  role: string;
  requestedBy: string;
  clientIp: string;
}

export type AuditAction = 
  | 'secret.read'
  | 'secret.create'
  | 'secret.update'
  | 'secret.rotate'
  | 'secret.delete'
  | 'secret.rollback'
  | 'lease.issue'
  | 'lease.renew'
  | 'lease.revoke'
  | 'vault.unseal'
  | 'vault.seal'
  | 'token.create'
  | 'token.revoke'
  | 'policy.update';

export interface AuditActor {
  name: string;
  email: string;
  type: 'user' | 'service-token' | 'system';
}

export interface AuditLogEntry {
  id: string;
  timestamp: string;
  actor: AuditActor;
  action: AuditAction;
  resource: string;
  environment: Environment | 'global';
  clientIp: string;
  clientSource: 'cli' | 'web-console' | 'k8s-operator' | 'sdk-python' | 'sdk-node' | 'terraform';
  diff?: {
    before?: string;
    after?: string;
    details?: string;
  };
  status: 'success' | 'denied' | 'error';
  prevHash: string;
  tamperHash: string;
}

export interface ServiceToken {
  id: string;
  name: string;
  tokenPrefix: string;
  createdAt: string;
  lastUsedAt: string;
  expiresAt: string | null;
  environmentScope: Environment | 'all';
  pathPattern: string;
  policies: ('read' | 'write' | 'rotate' | 'dynamic_issue')[];
  status: 'active' | 'revoked';
}

export interface VaultCryptoState {
  isSealed: boolean;
  initialized: boolean;
  algorithm: 'AES-256-GCM';
  keyEpoch: number;
  shamirThreshold: number;
  shamirTotalShares: number;
  submittedShares: string[];
}

export type NavTab = 
  | 'secrets' 
  | 'dynamic' 
  | 'rotation' 
  | 'audit' 
  | 'tokens' 
  | 'cli-sdk' 
  | 'crypto';
