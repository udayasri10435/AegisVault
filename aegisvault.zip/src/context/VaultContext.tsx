import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { 
  Secret, 
  DynamicEngineConfig, 
  DynamicLease, 
  AuditLogEntry, 
  ServiceToken, 
  Environment, 
  VaultCryptoState,
  NavTab,
  AuditAction,
  RotationStrategy
} from '../types/vault';
import { 
  INITIAL_SECRETS, 
  INITIAL_DYNAMIC_ENGINES, 
  INITIAL_DYNAMIC_LEASES, 
  INITIAL_AUDIT_LOGS, 
  INITIAL_SERVICE_TOKENS 
} from '../lib/mockData';
import { 
  fastHash, 
  generateRandomSecret, 
  generateDynamicDbCredential, 
  generateDynamicAwsCredential,
  DEFAULT_SHAMIR_SHARES 
} from '../lib/cryptoUtils';

export interface ToastMessage {
  id: string;
  type: 'success' | 'info' | 'warning' | 'error';
  title: string;
  message: string;
}

interface VaultContextType {
  // Navigation & Environment
  currentTab: NavTab;
  setCurrentTab: (tab: NavTab) => void;
  selectedEnv: Environment | 'all';
  setSelectedEnv: (env: Environment | 'all') => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  isCommandPaletteOpen: boolean;
  setIsCommandPaletteOpen: (open: boolean) => void;

  // Secrets & Versioning
  secrets: Secret[];
  filteredSecrets: Secret[];
  unmaskedSecretIds: Record<string, boolean>;
  toggleMaskSecret: (secretId: string) => void;
  createSecret: (secret: Omit<Secret, 'id' | 'createdAt' | 'updatedAt' | 'currentVersion' | 'versions'> & { initialValue: string }) => void;
  updateSecretValue: (secretId: string, newValue: string, changeReason: string) => void;
  rotateSecret: (secretId: string, customReason?: string) => Promise<void>;
  rollbackSecretVersion: (secretId: string, targetVersion: number) => void;
  deleteSecret: (secretId: string) => void;
  updateRotationPolicy: (secretId: string, policy: Partial<Secret['rotationPolicy']>) => void;
  batchRotateDueSecrets: () => Promise<number>;

  // Dynamic Credentials & Leases
  dynamicEngines: DynamicEngineConfig[];
  dynamicLeases: DynamicLease[];
  issueDynamicCredential: (engineId: string, role: string, ttlSeconds: number) => DynamicLease;
  renewDynamicLease: (leaseId: string, extensionSeconds?: number) => void;
  revokeDynamicLease: (leaseId: string) => void;

  // Tamper-Evident Audit Logging
  auditLogs: AuditLogEntry[];
  filteredAuditLogs: AuditLogEntry[];
  auditFilterActor: string;
  setAuditFilterActor: (actor: string) => void;
  auditFilterAction: string;
  setAuditFilterAction: (action: string) => void;
  verifyAuditChainIntegrity: () => { isValid: boolean; checkedBlocks: number; brokenBlockId?: string };

  // Machine Service Tokens
  serviceTokens: ServiceToken[];
  createServiceToken: (name: string, env: Environment | 'all', pathPattern: string, policies: ('read' | 'write' | 'rotate' | 'dynamic_issue')[]) => { token: ServiceToken; rawToken: string };
  revokeServiceToken: (tokenId: string) => void;

  // Vault Cryptography & Shamir Unseal
  cryptoState: VaultCryptoState;
  sealVault: () => void;
  submitShamirShare: (share: string) => { success: boolean; message: string; remainingNeeded: number };
  resetShamirUnseal: () => void;

  // Toasts
  toasts: ToastMessage[];
  addToast: (toast: Omit<ToastMessage, 'id'>) => void;
  removeToast: (id: string) => void;

  // Bulk Import / Export
  importSecretsFromEnv: (envContent: string, targetEnv: Environment) => number;
}

const VaultContext = createContext<VaultContextType | undefined>(undefined);

export const VaultProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentTab, setCurrentTab] = useState<NavTab>('secrets');
  const [selectedEnv, setSelectedEnv] = useState<Environment | 'all'>('production');
  const [searchQuery, setSearchQuery] = useState('');
  const [isCommandPaletteOpen, setIsCommandPaletteOpen] = useState(false);

  // Core Data
  const [secrets, setSecrets] = useState<Secret[]>(INITIAL_SECRETS);
  const [dynamicEngines] = useState<DynamicEngineConfig[]>(INITIAL_DYNAMIC_ENGINES);
  const [dynamicLeases, setDynamicLeases] = useState<DynamicLease[]>(INITIAL_DYNAMIC_LEASES);
  const [auditLogs, setAuditLogs] = useState<AuditLogEntry[]>(INITIAL_AUDIT_LOGS);
  const [serviceTokens, setServiceTokens] = useState<ServiceToken[]>(INITIAL_SERVICE_TOKENS);
  
  // Masking state (auto-expires reveal after 15s)
  const [unmaskedSecretIds, setUnmaskedSecretIds] = useState<Record<string, boolean>>({});

  // Audit filters
  const [auditFilterActor, setAuditFilterActor] = useState('all');
  const [auditFilterAction, setAuditFilterAction] = useState('all');

  // Cryptographic Vault State (Shamir's Secret Sharing)
  const [cryptoState, setCryptoState] = useState<VaultCryptoState>({
    isSealed: false,
    initialized: true,
    algorithm: 'AES-256-GCM',
    keyEpoch: 4,
    shamirThreshold: 3,
    shamirTotalShares: 5,
    submittedShares: []
  });

  // Toasts
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const addToast = useCallback((toast: Omit<ToastMessage, 'id'>) => {
    const id = `toast_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`;
    setToasts(prev => [...prev.slice(-4), { ...toast, id }]);
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id));
    }, 4500);
  }, []);

  const removeToast = useCallback((id: string) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  }, []);

  // Helper to record an audit entry into the cryptographic hash chain
  const recordAudit = useCallback((
    action: AuditAction,
    resource: string,
    environment: Environment | 'global',
    details: string,
    clientSource: AuditLogEntry['clientSource'] = 'web-console'
  ) => {
    setAuditLogs(prev => {
      const topEntry = prev[0];
      const prevHash = topEntry ? topEntry.tamperHash : '0000000000000000000000000000000000000000000000000000000000000000';
      const id = `aud_${Date.now().toString(36)}`;
      const timestamp = new Date().toISOString();
      const actor = {
        name: 'Elena Rostova (SecOps)',
        email: 'elena.rostova@aegis.corp',
        type: 'user' as const
      };
      
      const payload = `${prevHash}|${id}|${timestamp}|${actor.email}|${action}|${resource}`;
      const tamperHash = fastHash(payload);

      const newEntry: AuditLogEntry = {
        id,
        timestamp,
        actor,
        action,
        resource,
        environment,
        clientIp: '192.168.1.88',
        clientSource,
        diff: { details },
        status: 'success',
        prevHash,
        tamperHash
      };

      return [newEntry, ...prev];
    });
  }, []);

  // Toggle mask/unmask with 15s auto-remask for security
  const toggleMaskSecret = useCallback((secretId: string) => {
    setUnmaskedSecretIds(prev => {
      const isCurrentlyUnmasked = !!prev[secretId];
      if (!isCurrentlyUnmasked) {
        // Auto-remask after 15 seconds
        setTimeout(() => {
          setUnmaskedSecretIds(inner => ({ ...inner, [secretId]: false }));
        }, 15000);
        
        const sec = secrets.find(s => s.id === secretId);
        if (sec) {
          recordAudit('secret.read', `${sec.path}/${sec.name}`, sec.environment, `Secret unmasked in console for 15s session`);
        }
      }
      return { ...prev, [secretId]: !isCurrentlyUnmasked };
    });
  }, [secrets, recordAudit]);

  // Periodic lease status updater
  useEffect(() => {
    const interval = setInterval(() => {
      setDynamicLeases(prev => 
        prev.map(lease => {
          if (lease.status !== 'active') return lease;
          const isExpired = new Date(lease.expiresAt).getTime() <= Date.now();
          if (isExpired) {
            return { ...lease, status: 'expired' };
          }
          return lease;
        })
      );
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  // Create new secret
  const createSecret = useCallback((
    newSecretData: Omit<Secret, 'id' | 'createdAt' | 'updatedAt' | 'currentVersion' | 'versions'> & { initialValue: string }
  ) => {
    const id = `sec_${Date.now().toString(36)}`;
    const now = new Date().toISOString();
    const version: Secret['versions'][0] = {
      version: 1,
      value: newSecretData.initialValue,
      createdAt: now,
      author: 'elena.rostova@aegis.corp',
      changeReason: 'Initial creation',
      checksum: `sha256:${fastHash(newSecretData.initialValue).slice(0, 8)}...`
    };

    const newSecret: Secret = {
      ...newSecretData,
      id,
      createdAt: now,
      updatedAt: now,
      currentVersion: 1,
      versions: [version],
      status: 'active'
    };

    setSecrets(prev => [newSecret, ...prev]);
    recordAudit('secret.create', `${newSecret.path}/${newSecret.name}`, newSecret.environment, `Created new secret with initial value (v1)`);
    addToast({
      type: 'success',
      title: 'Secret Created',
      message: `${newSecret.name} stored in ${newSecret.environment} path`
    });
  }, [recordAudit, addToast]);

  // Update secret value manually (creates vN+1)
  const updateSecretValue = useCallback((secretId: string, newValue: string, changeReason: string) => {
    setSecrets(prev => prev.map(s => {
      if (s.id !== secretId) return s;
      const nextVersionNum = s.currentVersion + 1;
      const now = new Date().toISOString();
      const newVersion = {
        version: nextVersionNum,
        value: newValue,
        createdAt: now,
        author: 'elena.rostova@aegis.corp',
        changeReason: changeReason || `Manual value update to v${nextVersionNum}`,
        checksum: `sha256:${fastHash(newValue).slice(0, 8)}...`
      };

      recordAudit('secret.update', `${s.path}/${s.name}`, s.environment, `Updated secret from v${s.currentVersion} to v${nextVersionNum}: ${changeReason}`);
      return {
        ...s,
        currentVersion: nextVersionNum,
        updatedAt: now,
        status: 'active',
        versions: [newVersion, ...s.versions]
      };
    }));

    addToast({
      type: 'success',
      title: 'Secret Updated',
      message: `New version created and secured with AES-256-GCM`
    });
  }, [recordAudit, addToast]);

  // Rotate secret value
  const rotateSecret = useCallback(async (secretId: string, customReason?: string) => {
    const sec = secrets.find(s => s.id === secretId);
    if (!sec) return;

    let generatedValue = '';
    const strategy = sec.rotationPolicy.strategy;
    
    if (strategy === 'database-role') {
      const dbCred = generateDynamicDbCredential('rot_pg');
      generatedValue = dbCred.connectionString;
    } else if (strategy === 'aws-iam') {
      const awsCred = generateDynamicAwsCredential();
      generatedValue = `${awsCred.accessKeyId}:${awsCred.secretAccessKey}`;
    } else {
      generatedValue = generateRandomSecret(48, 'apikey');
    }

    const nextVer = sec.currentVersion + 1;
    const now = new Date().toISOString();
    const nextRotation = new Date(Date.now() + sec.rotationPolicy.intervalDays * 86400 * 1000).toISOString();

    const newVersion = {
      version: nextVer,
      value: generatedValue,
      createdAt: now,
      author: 'AutoRotationPolicyEngine',
      changeReason: customReason || `Rotation execution via ${strategy} policy`,
      checksum: `sha256:${fastHash(generatedValue).slice(0, 8)}...`
    };

    setSecrets(prev => prev.map(s => {
      if (s.id !== secretId) return s;
      return {
        ...s,
        currentVersion: nextVer,
        updatedAt: now,
        status: 'active',
        versions: [newVersion, ...s.versions],
        rotationPolicy: {
          ...s.rotationPolicy,
          lastRotatedAt: now,
          nextRotationAt: nextRotation,
          healthStatus: 'healthy'
        }
      };
    }));

    recordAudit('secret.rotate', `${sec.path}/${sec.name}`, sec.environment, `Rotated to version v${nextVer} using strategy [${strategy}]`);
    addToast({
      type: 'success',
      title: 'Secret Rotated Successfully',
      message: `${sec.name} rotated to v${nextVer}. Upstream services alerted.`
    });
  }, [secrets, recordAudit, addToast]);

  // Rollback to specific version
  const rollbackSecretVersion = useCallback((secretId: string, targetVersion: number) => {
    setSecrets(prev => prev.map(s => {
      if (s.id !== secretId) return s;
      const target = s.versions.find(v => v.version === targetVersion);
      if (!target) return s;

      const nextVer = s.currentVersion + 1;
      const now = new Date().toISOString();
      const rollbackVersion = {
        version: nextVer,
        value: target.value,
        createdAt: now,
        author: 'elena.rostova@aegis.corp',
        changeReason: `Rollback to prior version v${targetVersion} content`,
        checksum: target.checksum
      };

      recordAudit('secret.rollback', `${s.path}/${s.name}`, s.environment, `Rolled back ${s.name} from v${s.currentVersion} to v${targetVersion} content (minted as v${nextVer})`);
      return {
        ...s,
        currentVersion: nextVer,
        updatedAt: now,
        versions: [rollbackVersion, ...s.versions]
      };
    }));

    addToast({
      type: 'info',
      title: 'Version Rolled Back',
      message: `Restored version v${targetVersion} as latest deployment version`
    });
  }, [recordAudit, addToast]);

  // Delete secret
  const deleteSecret = useCallback((secretId: string) => {
    const sec = secrets.find(s => s.id === secretId);
    if (!sec) return;

    setSecrets(prev => prev.filter(s => s.id !== secretId));
    recordAudit('secret.delete', `${sec.path}/${sec.name}`, sec.environment, `Permanently purged secret ${sec.name} from vault`);
    addToast({
      type: 'warning',
      title: 'Secret Deleted',
      message: `${sec.name} has been destroyed from the cipher vault`
    });
  }, [secrets, recordAudit, addToast]);

  // Update secret rotation policy
  const updateRotationPolicy = useCallback((secretId: string, policy: Partial<Secret['rotationPolicy']>) => {
    setSecrets(prev => prev.map(s => {
      if (s.id !== secretId) return s;
      const updatedPolicy = { ...s.rotationPolicy, ...policy };
      recordAudit('policy.update', `${s.path}/${s.name}`, s.environment, `Updated rotation policy (interval: ${updatedPolicy.intervalDays}d, strategy: ${updatedPolicy.strategy})`);
      return { ...s, rotationPolicy: updatedPolicy };
    }));
    addToast({
      type: 'info',
      title: 'Rotation Policy Updated',
      message: 'New rotation interval and automated schedule active'
    });
  }, [recordAudit, addToast]);

  // Batch rotate all overdue secrets
  const batchRotateDueSecrets = useCallback(async () => {
    const dueSecrets = secrets.filter(s => s.rotationPolicy.healthStatus === 'due' || s.rotationPolicy.healthStatus === 'overdue');
    for (const sec of dueSecrets) {
      await rotateSecret(sec.id, 'Batch compliance auto-rotation');
    }
    return dueSecrets.length;
  }, [secrets, rotateSecret]);

  // Issue dynamic credential
  const issueDynamicCredential = useCallback((engineId: string, role: string, ttlSeconds: number): DynamicLease => {
    const now = new Date();
    const expiresAt = new Date(now.getTime() + ttlSeconds * 1000).toISOString();
    const leaseId = `lease_${engineId.slice(0, 3)}_${generateRandomSecret(8, 'hex')}`;

    let username = '';
    let credentials: Record<string, string> = {};
    let targetResource = '';

    if (engineId === 'postgresql') {
      const dbCred = generateDynamicDbCredential('v_app_u');
      username = dbCred.username;
      credentials = {
        username: dbCred.username,
        password: dbCred.password,
        connectionString: dbCred.connectionString,
        role: role
      };
      targetResource = 'primary-pg.internal.aegis:5432/core_production';
    } else if (engineId === 'aws-sts') {
      const awsCred = generateDynamicAwsCredential();
      username = `aegis-sts-${generateRandomSecret(6, 'hex')}`;
      credentials = {
        AccessKeyId: awsCred.accessKeyId,
        SecretAccessKey: awsCred.secretAccessKey,
        SessionToken: awsCred.sessionToken,
        Expiration: awsCred.expiration
      };
      targetResource = 'arn:aws:iam::123456789012:role/aegis-production-runner';
    } else if (engineId === 'redis') {
      const randPass = generateRandomSecret(24, 'alphanumeric');
      username = `v_redis_${generateRandomSecret(4, 'hex')}`;
      credentials = {
        username,
        password: randPass,
        allowedKeyspace: 'app:cache:*'
      };
      targetResource = 'rediss://cache-cluster.internal.aegis:6379';
    } else {
      const randToken = `ghs_dyn_${generateRandomSecret(32, 'alphanumeric')}`;
      username = `deploy-runner-${generateRandomSecret(4, 'hex')}`;
      credentials = {
        token: randToken,
        scope: 'contents:read, deployments:write'
      };
      targetResource = 'github.com/aegis-enterprise/core-services';
    }

    const newLease: DynamicLease = {
      leaseId,
      engine: engineId as any,
      targetResource,
      username,
      credentials,
      issuedAt: now.toISOString(),
      expiresAt,
      ttlSeconds,
      status: 'active',
      role,
      requestedBy: 'elena.rostova@aegis.corp',
      clientIp: '192.168.1.88'
    };

    setDynamicLeases(prev => [newLease, ...prev]);
    recordAudit('lease.issue', `${engineId}:${leaseId}`, 'production', `Minted dynamic credential lease ${leaseId} (${role}, TTL ${ttlSeconds}s)`);
    addToast({
      type: 'success',
      title: 'Dynamic Lease Minted',
      message: `Issued ephemeral credentials for ${engineId}. Auto-revokes at ${new Date(expiresAt).toLocaleTimeString()}`
    });

    return newLease;
  }, [recordAudit, addToast]);

  // Renew lease
  const renewDynamicLease = useCallback((leaseId: string, extensionSeconds = 3600) => {
    setDynamicLeases(prev => prev.map(lease => {
      if (lease.leaseId !== leaseId) return lease;
      const currentExpiry = new Date(lease.expiresAt).getTime();
      const newExpiry = new Date(Math.max(Date.now(), currentExpiry) + extensionSeconds * 1000).toISOString();
      recordAudit('lease.renew', `${lease.engine}:${lease.leaseId}`, 'production', `Renewed lease ${leaseId} for +${extensionSeconds}s`);
      return {
        ...lease,
        expiresAt: newExpiry,
        status: 'active'
      };
    }));
    addToast({
      type: 'info',
      title: 'Lease Extended',
      message: `Lease ${leaseId} renewed for additional ${Math.floor(extensionSeconds / 60)} minutes`
    });
  }, [recordAudit, addToast]);

  // Revoke lease
  const revokeDynamicLease = useCallback((leaseId: string) => {
    setDynamicLeases(prev => prev.map(lease => {
      if (lease.leaseId !== leaseId) return lease;
      recordAudit('lease.revoke', `${lease.engine}:${lease.leaseId}`, 'production', `Immediately revoked dynamic credential lease ${leaseId} and dropped database role`);
      return {
        ...lease,
        status: 'revoked'
      };
    }));
    addToast({
      type: 'warning',
      title: 'Lease Revoked',
      message: `Ephemeral credentials invalidated immediately`
    });
  }, [recordAudit, addToast]);

  // Verify Audit Chain
  const verifyAuditChainIntegrity = useCallback(() => {
    // Audit logs are stored newest-first. Verify chain from oldest to newest.
    const reversed = [...auditLogs].reverse();
    let currentHash = '0000000000000000000000000000000000000000000000000000000000000000';

    for (let i = 0; i < reversed.length; i++) {
      const entry = reversed[i];
      if (entry.prevHash !== currentHash) {
        return { isValid: false, checkedBlocks: i, brokenBlockId: entry.id };
      }
      const expectedPayload = `${entry.prevHash}|${entry.id}|${entry.timestamp}|${entry.actor.email}|${entry.action}|${entry.resource}`;
      const computedTamperHash = fastHash(expectedPayload);
      if (computedTamperHash !== entry.tamperHash) {
        return { isValid: false, checkedBlocks: i, brokenBlockId: entry.id };
      }
      currentHash = entry.tamperHash;
    }

    return { isValid: true, checkedBlocks: reversed.length };
  }, [auditLogs]);

  // Create machine service token
  const createServiceToken = useCallback((
    name: string, 
    env: Environment | 'all', 
    pathPattern: string, 
    policies: ('read' | 'write' | 'rotate' | 'dynamic_issue')[]
  ) => {
    const rawSecret = generateRandomSecret(40, 'alphanumeric');
    const tokenPrefix = `aeg_live_tok_${generateRandomSecret(4, 'hex')}`;
    const rawToken = `${tokenPrefix}_${rawSecret}`;
    const id = `tok_${Date.now().toString(36)}`;
    const now = new Date().toISOString();

    const newToken: ServiceToken = {
      id,
      name,
      tokenPrefix,
      createdAt: now,
      lastUsedAt: 'Never',
      expiresAt: new Date(Date.now() + 365 * 86400 * 1000).toISOString(),
      environmentScope: env,
      pathPattern,
      policies,
      status: 'active'
    };

    setServiceTokens(prev => [newToken, ...prev]);
    recordAudit('token.create', `tokens/${id}`, 'global', `Created machine service token "${name}" with permissions [${policies.join(', ')}]`);
    addToast({
      type: 'success',
      title: 'Service Token Generated',
      message: `New scoped machine token minted. Copy immediately.`
    });

    return { token: newToken, rawToken };
  }, [recordAudit, addToast]);

  // Revoke service token
  const revokeServiceToken = useCallback((tokenId: string) => {
    setServiceTokens(prev => prev.map(t => {
      if (t.id !== tokenId) return t;
      recordAudit('token.revoke', `tokens/${t.id}`, 'global', `Revoked service token "${t.name}"`);
      return { ...t, status: 'revoked' };
    }));
    addToast({
      type: 'warning',
      title: 'Token Revoked',
      message: 'Service token access denied permanently'
    });
  }, [recordAudit, addToast]);

  // Seal Vault
  const sealVault = useCallback(() => {
    setCryptoState(prev => ({
      ...prev,
      isSealed: true,
      submittedShares: []
    }));
    setUnmaskedSecretIds({});
    recordAudit('vault.seal', 'vault/master-key', 'global', 'Vault master key sealed. Cryptographic memory cleared.');
    addToast({
      type: 'warning',
      title: 'Vault Sealed',
      message: 'All in-memory cryptographic keys wiped. Shamir unseal required.'
    });
  }, [recordAudit, addToast]);

  // Submit Shamir Share
  const submitShamirShare = useCallback((share: string) => {
    const trimmed = share.trim();
    if (!DEFAULT_SHAMIR_SHARES.includes(trimmed)) {
      return { success: false, message: 'Invalid Shamir cryptographic key share', remainingNeeded: cryptoState.shamirThreshold - cryptoState.submittedShares.length };
    }

    if (cryptoState.submittedShares.includes(trimmed)) {
      return { success: false, message: 'This key share has already been registered', remainingNeeded: cryptoState.shamirThreshold - cryptoState.submittedShares.length };
    }

    const updatedShares = [...cryptoState.submittedShares, trimmed];
    const needed = cryptoState.shamirThreshold - updatedShares.length;

    if (needed <= 0) {
      setCryptoState(prev => ({
        ...prev,
        isSealed: false,
        submittedShares: updatedShares
      }));
      recordAudit('vault.unseal', 'vault/master-key', 'global', 'Vault unsealed using 3 of 5 Shamir shares. AES-256-GCM master ring reconstructed.');
      addToast({
        type: 'success',
        title: 'Vault Unsealed',
        message: 'Master key reconstructed successfully. Secure operations restored.'
      });
      return { success: true, message: 'Vault successfully unsealed!', remainingNeeded: 0 };
    } else {
      setCryptoState(prev => ({
        ...prev,
        submittedShares: updatedShares
      }));
      return { success: true, message: `Key share accepted. ${needed} more required to unseal.`, remainingNeeded: needed };
    }
  }, [cryptoState, recordAudit, addToast]);

  const resetShamirUnseal = useCallback(() => {
    setCryptoState(prev => ({ ...prev, submittedShares: [] }));
  }, []);

  // Import from .env
  const importSecretsFromEnv = useCallback((envContent: string, targetEnv: Environment): number => {
    const lines = envContent.split('\n');
    let importedCount = 0;
    const now = new Date().toISOString();

    const newSecretsToAdd: Secret[] = [];

    lines.forEach(line => {
      const trimmed = line.trim();
      if (!trimmed || trimmed.startsWith('#')) return;
      const eqIdx = trimmed.indexOf('=');
      if (eqIdx === -1) return;

      const rawKey = trimmed.slice(0, eqIdx).trim();
      let rawVal = trimmed.slice(eqIdx + 1).trim();

      // strip quotes if wrapped
      if ((rawVal.startsWith('"') && rawVal.endsWith('"')) || (rawVal.startsWith("'") && rawVal.endsWith("'"))) {
        rawVal = rawVal.slice(1, -1);
      }

      if (!rawKey) return;

      const id = `sec_${Date.now().toString(36)}_${Math.random().toString(36).substr(2, 4)}`;
      newSecretsToAdd.push({
        id,
        name: rawKey,
        path: `env/${targetEnv}`,
        environment: targetEnv,
        currentVersion: 1,
        versions: [{
          version: 1,
          value: rawVal,
          createdAt: now,
          author: 'elena.rostova@aegis.corp',
          changeReason: 'Bulk imported from .env config',
          checksum: `sha256:${fastHash(rawVal).slice(0, 8)}...`
        }],
        rotationPolicy: {
          enabled: false,
          intervalDays: 60,
          autoRotate: false,
          lastRotatedAt: now,
          nextRotationAt: new Date(Date.now() + 60 * 86400 * 1000).toISOString(),
          strategy: 'crypto-random',
          healthStatus: 'healthy'
        },
        tags: ['imported', targetEnv],
        description: `Imported environment variable ${rawKey}`,
        createdAt: now,
        updatedAt: now,
        status: 'active'
      });
      importedCount++;
    });

    if (importedCount > 0) {
      setSecrets(prev => [...newSecretsToAdd, ...prev]);
      recordAudit('secret.create', `bulk-import/${targetEnv}`, targetEnv, `Bulk imported ${importedCount} secrets from .env format`);
      addToast({
        type: 'success',
        title: 'Bulk Import Completed',
        message: `Imported ${importedCount} secrets into ${targetEnv} environment`
      });
    }

    return importedCount;
  }, [recordAudit, addToast]);

  // Computed filter states
  const filteredSecrets = secrets.filter(sec => {
    const matchesEnv = selectedEnv === 'all' || sec.environment === selectedEnv;
    const matchesQuery = !searchQuery || 
      sec.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      sec.path.toLowerCase().includes(searchQuery.toLowerCase()) ||
      sec.tags.some(t => t.toLowerCase().includes(searchQuery.toLowerCase())) ||
      sec.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesEnv && matchesQuery;
  });

  const filteredAuditLogs = auditLogs.filter(entry => {
    const matchesEnv = selectedEnv === 'all' || entry.environment === selectedEnv || entry.environment === 'global';
    const matchesActor = auditFilterActor === 'all' || entry.actor.email === auditFilterActor || entry.actor.type === auditFilterActor;
    const matchesAction = auditFilterAction === 'all' || entry.action === auditFilterAction;
    const matchesQuery = !searchQuery ||
      entry.resource.toLowerCase().includes(searchQuery.toLowerCase()) ||
      entry.actor.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      entry.actor.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      entry.diff?.details?.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesEnv && matchesActor && matchesAction && matchesQuery;
  });

  return (
    <VaultContext.Provider value={{
      currentTab,
      setCurrentTab,
      selectedEnv,
      setSelectedEnv,
      searchQuery,
      setSearchQuery,
      isCommandPaletteOpen,
      setIsCommandPaletteOpen,
      secrets,
      filteredSecrets,
      unmaskedSecretIds,
      toggleMaskSecret,
      createSecret,
      updateSecretValue,
      rotateSecret,
      rollbackSecretVersion,
      deleteSecret,
      updateRotationPolicy,
      batchRotateDueSecrets,
      dynamicEngines,
      dynamicLeases,
      issueDynamicCredential,
      renewDynamicLease,
      revokeDynamicLease,
      auditLogs,
      filteredAuditLogs,
      auditFilterActor,
      setAuditFilterActor,
      auditFilterAction,
      setAuditFilterAction,
      verifyAuditChainIntegrity,
      serviceTokens,
      createServiceToken,
      revokeServiceToken,
      cryptoState,
      sealVault,
      submitShamirShare,
      resetShamirUnseal,
      toasts,
      addToast,
      removeToast,
      importSecretsFromEnv
    }}>
      {children}
    </VaultContext.Provider>
  );
};

export const useVault = () => {
  const context = useContext(VaultContext);
  if (!context) {
    throw new Error('useVault must be used within a VaultProvider');
  }
  return context;
};
